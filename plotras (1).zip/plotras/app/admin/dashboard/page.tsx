import GovtAdminDashboard from "@/components/admin/GovtAdminDashboard";
import SiteHeader from "@/components/layout/SiteHeader";

export default function AdminDashboardPage() {
  return (
    <main className="min-h-screen bg-canvas">
      <SiteHeader />
      <GovtAdminDashboard />
    </main>
  );
}
