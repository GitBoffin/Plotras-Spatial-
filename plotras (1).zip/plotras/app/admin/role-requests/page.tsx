import RoleRequestsPanel from "@/components/admin/RoleRequestsPanel";
import SiteHeader from "@/components/layout/SiteHeader";

export default function RoleRequestsPage() {
  return (
    <main className="min-h-screen bg-canvas">
      <SiteHeader />
      <RoleRequestsPanel />
    </main>
  );
}
