import ZoneManager from "@/components/admin/ZoneManager";
import SiteHeader from "@/components/layout/SiteHeader";

export default function ZonesPage() {
  return (
    <main className="min-h-screen bg-canvas">
      <SiteHeader />
      <ZoneManager />
    </main>
  );
}
