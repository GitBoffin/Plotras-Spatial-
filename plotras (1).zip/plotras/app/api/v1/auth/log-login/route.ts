// =====================================================================
// PLOTRAS — POST /api/v1/auth/log-login
// =====================================================================
// FR-009 (Audit Logging) lists "Login" as a minimum audited event
// category. The client (browser Supabase client) can't write to
// audit_logs directly — RLS on that table has no client-facing insert
// policy, only the service role writes it — so AuthForm.tsx calls this
// right after a successful sign-in/sign-up to record it server-side.
// =====================================================================

import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

export async function POST(req: NextRequest) {
  const authHeader = req.headers.get("authorization");
  if (!authHeader?.startsWith("Bearer ")) {
    return NextResponse.json({ error: { code: "ERR_UNAUTHENTICATED", message: "Missing bearer token." } }, { status: 401 });
  }
  const jwt = authHeader.slice("Bearer ".length);

  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { persistSession: false } }
  );

  const { data: userData, error } = await supabase.auth.getUser(jwt);
  if (error || !userData.user) {
    return NextResponse.json({ error: { code: "ERR_UNAUTHENTICATED", message: "Invalid session." } }, { status: 401 });
  }

  await supabase.from("audit_logs").insert({
    entity_type: "user",
    entity_id: userData.user.id,
    action: "LOGIN",
    performed_by: userData.user.id,
    ip_address: req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? null,
    new_state: { email: userData.user.email },
  });

  return NextResponse.json({ logged: true });
}
