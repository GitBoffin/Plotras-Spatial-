// =====================================================================
// PLOTRAS — POST /api/v1/b2b/title-verification
// =====================================================================
// PRD Section 4, "Bank APIs": API key and/or JWT; BANK_OFFICER
// authorization; example limit 500 requests/minute/client. mTLS is
// explicitly NOT implemented here — that's an infrastructure-level
// concern (client-cert termination at a load balancer / API gateway),
// not something a Next.js route handler does.
//
// Auth model: X-API-Key header, hashed and matched against api_clients
// (see rate_limiting_and_api_clients migration). The plaintext key is
// generated once by /api/v1/bank/api-keys and never stored — only its
// SHA-256 hash is, so this route can never leak a usable key even if
// its own database is compromised.
// =====================================================================

import { NextRequest, NextResponse } from "next/server";
import { createClient, SupabaseClient } from "@supabase/supabase-js";
import { createHash } from "crypto";
import { VerifyRequestSchema, runSpatialVerification } from "@/lib/verify/runSpatialVerification";

interface ApiErrorBody {
  error: { code: string; message: string; details?: unknown[]; timestamp: string };
}

function errorResponse(status: number, code: string, message: string, details?: unknown[]): NextResponse<ApiErrorBody> {
  return NextResponse.json(
    { error: { code, message, ...(details ? { details } : {}), timestamp: new Date().toISOString() } },
    { status }
  );
}

function getServiceClient(): SupabaseClient {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { persistSession: false } }
  );
}

export async function POST(req: NextRequest) {
  const apiKey = req.headers.get("x-api-key");
  if (!apiKey) {
    return errorResponse(401, "ERR_UNAUTHENTICATED", "Missing X-API-Key header.");
  }

  const supabase = getServiceClient();
  const keyHash = createHash("sha256").update(apiKey).digest("hex");

  const { data: client, error: clientError } = await supabase
    .from("api_clients")
    .select("id, client_name, rate_limit_per_minute, revoked")
    .eq("api_key_hash", keyHash)
    .maybeSingle();

  if (clientError || !client || client.revoked) {
    return errorResponse(401, "ERR_UNAUTHENTICATED", "Invalid or revoked API key.");
  }

  const { data: withinLimit } = await supabase.rpc("fn_rate_limit_check", {
    p_bucket_key: `client:${client.id}:b2b.title-verification`,
    p_limit: client.rate_limit_per_minute,
    p_window_seconds: 60,
  });
  if (withinLimit === false) {
    return errorResponse(
      429,
      "ERR_RATE_LIMIT_EXCEEDED",
      `Rate limit of ${client.rate_limit_per_minute} requests/minute/client exceeded.`
    );
  }

  let payload: unknown;
  try {
    payload = await req.json();
  } catch {
    return errorResponse(400, "ERR_INVALID_PAYLOAD", "Request body must be valid JSON.");
  }

  const parsed = VerifyRequestSchema.safeParse(payload);
  if (!parsed.success) {
    return errorResponse(400, "ERR_INVALID_PAYLOAD", "Request failed schema validation.", parsed.error.issues);
  }

  const result = await runSpatialVerification(supabase, parsed.data.beacons);

  if (!result.ok) {
    return errorResponse(result.status, result.code, result.message, result.details);
  }

  await supabase.from("audit_logs").insert({
    entity_type: "spatial_verification",
    entity_id: client.id,
    action: "B2B_TITLE_VERIFICATION",
    new_state: {
      client_name: client.client_name,
      search_mode: "BEACONS",
      beacon_count: result.auditContext.beaconCount,
      source_srid: result.auditContext.sourceSrid,
      target_srid: result.auditContext.targetSrid,
      result: result.data,
    },
  });

  return NextResponse.json({ status: "success", data: result.data }, { status: 200 });
}
