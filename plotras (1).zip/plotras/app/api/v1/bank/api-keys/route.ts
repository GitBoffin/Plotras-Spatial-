// =====================================================================
// PLOTRAS — /api/v1/bank/api-keys
// =====================================================================
// BANK_OFFICER-only. POST issues a new key (plaintext shown exactly
// once — only its SHA-256 hash is ever persisted). GET lists the
// caller's own clients (metadata only, never the key). DELETE revokes.
// =====================================================================

import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import { createHash, randomBytes } from "crypto";
import { z } from "zod";

function getServiceClient() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { persistSession: false } }
  );
}

function errorResponse(status: number, code: string, message: string) {
  return NextResponse.json({ error: { code, message, timestamp: new Date().toISOString() } }, { status });
}

async function requireBankOfficer(req: NextRequest) {
  const authHeader = req.headers.get("authorization");
  if (!authHeader?.startsWith("Bearer ")) return { error: errorResponse(401, "ERR_UNAUTHENTICATED", "Missing bearer token.") };
  const jwt = authHeader.slice("Bearer ".length);

  const supabase = getServiceClient();
  const { data: userData, error: userError } = await supabase.auth.getUser(jwt);
  if (userError || !userData.user) return { error: errorResponse(401, "ERR_UNAUTHENTICATED", "Invalid session.") };

  const { data: profile } = await supabase.from("users").select("role").eq("id", userData.user.id).single();
  if (profile?.role !== "BANK_OFFICER") {
    return { error: errorResponse(403, "ERR_FORBIDDEN", "Only BANK_OFFICER accounts may manage API keys.") };
  }

  return { supabase, userId: userData.user.id };
}

export async function GET(req: NextRequest) {
  const ctx = await requireBankOfficer(req);
  if ("error" in ctx) return ctx.error;

  const { data } = await ctx.supabase
    .from("api_clients")
    .select("id, client_name, rate_limit_per_minute, revoked, created_at")
    .eq("bank_id", ctx.userId)
    .order("created_at", { ascending: false });

  return NextResponse.json({ clients: data ?? [] });
}

const CreateKeySchema = z.object({ client_name: z.string().min(1) });

export async function POST(req: NextRequest) {
  const ctx = await requireBankOfficer(req);
  if ("error" in ctx) return ctx.error;

  let payload: unknown;
  try {
    payload = await req.json();
  } catch {
    return errorResponse(400, "ERR_INVALID_PAYLOAD", "Request body must be valid JSON.");
  }
  const parsed = CreateKeySchema.safeParse(payload);
  if (!parsed.success) return errorResponse(400, "ERR_INVALID_PAYLOAD", "client_name is required.");

  // 32 random bytes, base64url — the plaintext key. Shown once, below,
  // and never again: only its hash is persisted.
  const plaintextKey = `plt_${randomBytes(32).toString("base64url")}`;
  const keyHash = createHash("sha256").update(plaintextKey).digest("hex");

  const { data, error } = await ctx.supabase
    .from("api_clients")
    .insert({ bank_id: ctx.userId, client_name: parsed.data.client_name, api_key_hash: keyHash })
    .select("id, client_name, rate_limit_per_minute, created_at")
    .single();

  if (error || !data) return errorResponse(500, "ERR_API_KEY_CREATION_FAILED", "Could not create the API key.");

  return NextResponse.json({ ...data, api_key: plaintextKey });
}

const RevokeSchema = z.object({ client_id: z.string().uuid() });

export async function DELETE(req: NextRequest) {
  const ctx = await requireBankOfficer(req);
  if ("error" in ctx) return ctx.error;

  let payload: unknown;
  try {
    payload = await req.json();
  } catch {
    return errorResponse(400, "ERR_INVALID_PAYLOAD", "Request body must be valid JSON.");
  }
  const parsed = RevokeSchema.safeParse(payload);
  if (!parsed.success) return errorResponse(400, "ERR_INVALID_PAYLOAD", "client_id is required.");

  const { error } = await ctx.supabase
    .from("api_clients")
    .update({ revoked: true })
    .eq("id", parsed.data.client_id)
    .eq("bank_id", ctx.userId); // can't revoke another bank's key

  if (error) return errorResponse(500, "ERR_API_KEY_REVOKE_FAILED", "Could not revoke the API key.");
  return NextResponse.json({ revoked: true });
}
