// =====================================================================
// PLOTRAS — POST /api/v1/bank/lien-discharge
// =====================================================================
// PRD FR-005 AC 9: "Lien discharge changes the parcel back to the
// applicable eligible state." Same financial/state-changing endpoint
// discipline as lien-lock: Idempotency-Key required, row-locked
// transaction via fn_lien_discharge, immutable audit event (AC 10).
// RBAC (Section 5 matrix): BANK_OFFICER discharges their own bank's
// lien; GOVT_ADMIN may discharge any lien (regulatory override) —
// enforced here by passing caller role/id into fn_lien_discharge.
// =====================================================================

import { NextRequest, NextResponse } from "next/server";
import { createClient, SupabaseClient } from "@supabase/supabase-js";
import { z } from "zod";

const DischargeRequestSchema = z.object({
  spatial_id: z.string().min(1),
  loan_reference_no: z.string().min(1),
});

interface ApiErrorBody {
  error: { code: string; message: string; details?: unknown[]; timestamp: string };
}

function errorResponse(status: number, code: string, message: string, details?: unknown[]) {
  return NextResponse.json<ApiErrorBody>(
    { error: { code, message, ...(details ? { details } : {}), timestamp: new Date().toISOString() } },
    { status }
  );
}

function getServiceClient(): SupabaseClient {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { persistSession: false } }
  );
}

const ENDPOINT_ID = "bank.lien-discharge";

export async function POST(req: NextRequest) {
  const authHeader = req.headers.get("authorization");
  if (!authHeader?.startsWith("Bearer ")) {
    return errorResponse(401, "ERR_UNAUTHENTICATED", "Missing or invalid bearer token.");
  }
  const jwt = authHeader.slice("Bearer ".length);

  const idempotencyKey = req.headers.get("idempotency-key");
  if (!idempotencyKey || !z.string().uuid().safeParse(idempotencyKey).success) {
    return errorResponse(
      400,
      "ERR_MISSING_IDEMPOTENCY_KEY",
      "A UUID Idempotency-Key header is required for this endpoint."
    );
  }

  const supabase = getServiceClient();

  const { data: userData, error: userError } = await supabase.auth.getUser(jwt);
  if (userError || !userData.user) {
    return errorResponse(401, "ERR_UNAUTHENTICATED", "Invalid or expired session.");
  }

  const { data: profile, error: profileError } = await supabase
    .from("users")
    .select("role")
    .eq("id", userData.user.id)
    .single();

  if (profileError || !profile) {
    return errorResponse(403, "ERR_FORBIDDEN", "No Plotras profile found for this account.");
  }
  if (profile.role !== "BANK_OFFICER" && profile.role !== "GOVT_ADMIN") {
    return errorResponse(
      403,
      "ERR_FORBIDDEN",
      "Only BANK_OFFICER or GOVT_ADMIN accounts may discharge a lien."
    );
  }

  const { data: existingKey } = await supabase
    .from("idempotency_keys")
    .select("response_status, response_body")
    .eq("key", idempotencyKey)
    .eq("endpoint", ENDPOINT_ID)
    .maybeSingle();

  if (existingKey) {
    return NextResponse.json(existingKey.response_body, { status: existingKey.response_status });
  }

  let payload: unknown;
  try {
    payload = await req.json();
  } catch {
    return errorResponse(400, "ERR_INVALID_PAYLOAD", "Request body must be valid JSON.");
  }

  const parsed = DischargeRequestSchema.safeParse(payload);
  if (!parsed.success) {
    return errorResponse(400, "ERR_INVALID_PAYLOAD", "Request failed schema validation.", parsed.error.issues);
  }
  const { spatial_id, loan_reference_no } = parsed.data;

  const { data: dischargeResult, error: dischargeError } = await supabase.rpc("fn_lien_discharge", {
    p_spatial_id: spatial_id,
    p_loan_reference: loan_reference_no,
    p_caller_id: userData.user.id,
    p_caller_is_admin: profile.role === "GOVT_ADMIN",
  });

  if (dischargeError) {
    const msg = dischargeError.message ?? "";
    let response: NextResponse<ApiErrorBody>;

    if (msg.includes("ERR_PARCEL_NOT_FOUND")) {
      response = errorResponse(404, "ERR_PARCEL_NOT_FOUND", `No parcel found for spatial_id ${spatial_id}.`);
    } else if (msg.includes("ERR_LIEN_NOT_FOUND")) {
      response = errorResponse(
        404,
        "ERR_LIEN_NOT_FOUND",
        `No active lien with reference ${loan_reference_no} was found on ${spatial_id}.`
      );
    } else if (msg.includes("ERR_FORBIDDEN")) {
      response = errorResponse(403, "ERR_FORBIDDEN", "You did not register this lien and are not authorized to discharge it.");
    } else {
      response = errorResponse(500, "ERR_LIEN_DISCHARGE_FAILURE", "The lien discharge could not be completed.");
    }

    await supabase.from("idempotency_keys").insert({
      key: idempotencyKey,
      endpoint: ENDPOINT_ID,
      response_status: response.status,
      response_body: await response.clone().json(),
    });
    return response;
  }

  const row = dischargeResult?.[0];
  const responseBody = {
    status: "success",
    message: `Lien ${loan_reference_no} discharged from ${spatial_id}. Property status updated.`,
    new_property_status: row?.new_status ?? "STATE_APPROVED",
    discharged_at: row?.discharged_at,
  };

  await supabase.from("idempotency_keys").insert({
    key: idempotencyKey,
    endpoint: ENDPOINT_ID,
    response_status: 200,
    response_body: responseBody,
  });

  return NextResponse.json(responseBody, { status: 200 });
}
