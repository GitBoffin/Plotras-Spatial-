// =====================================================================
// PLOTRAS — POST /api/v1/bank/lien-lock
// =====================================================================
// PRD: bank officers register a lien against a STATE_APPROVED parcel,
// flipping it to MORTGAGE_LOCKED. This is a financial/state-changing
// endpoint, so per PRD API Spec Standards it requires an
// Idempotency-Key header, and per the Edge Cases table concurrent
// lock attempts must resolve to ERR_LIEN_LOCK_CONFLICT (409) for the
// loser rather than a race condition. Both are handled by fn_lien_lock
// (supabase migration lien_lock_and_idempotency), which does the
// SELECT ... FOR UPDATE row-locking inside one Postgres transaction.
// =====================================================================

import { NextRequest, NextResponse } from "next/server";
import { createClient, SupabaseClient } from "@supabase/supabase-js";
import { z } from "zod";

const LienLockRequestSchema = z.object({
  spatial_id: z.string().min(1),
  loan_reference_no: z.string().min(1),
  facility_amount: z.number().positive(),
  bank_code: z.string().min(1),
});

interface ApiErrorBody {
  error: {
    code: string;
    message: string;
    details?: unknown[];
    timestamp: string;
  };
}

function errorResponse(status: number, code: string, message: string, details?: unknown[]) {
  return NextResponse.json<ApiErrorBody>(
    { error: { code, message, ...(details ? { details } : {}), timestamp: new Date().toISOString() } },
    { status }
  );
}

function getServiceClient(): SupabaseClient {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { persistSession: false } }
  );
}

const ENDPOINT_ID = "bank.lien-lock";

export async function POST(req: NextRequest) {
  const authHeader = req.headers.get("authorization");
  if (!authHeader?.startsWith("Bearer ")) {
    return errorResponse(401, "ERR_UNAUTHENTICATED", "Missing or invalid bearer token.");
  }
  const jwt = authHeader.slice("Bearer ".length);

  // PRD API Spec Standards: financial/state-changing endpoints require
  // Idempotency-Key.
  const idempotencyKey = req.headers.get("idempotency-key");
  if (!idempotencyKey || !z.string().uuid().safeParse(idempotencyKey).success) {
    return errorResponse(
      400,
      "ERR_MISSING_IDEMPOTENCY_KEY",
      "A UUID Idempotency-Key header is required for this endpoint."
    );
  }

  const supabase = getServiceClient();

  // --- Resolve + authorize the caller ---
  const { data: userData, error: userError } = await supabase.auth.getUser(jwt);
  if (userError || !userData.user) {
    return errorResponse(401, "ERR_UNAUTHENTICATED", "Invalid or expired session.");
  }

  const { data: profile, error: profileError } = await supabase
    .from("users")
    .select("role")
    .eq("id", userData.user.id)
    .single();

  if (profileError || !profile) {
    return errorResponse(403, "ERR_FORBIDDEN", "No Plotras profile found for this account.");
  }
  if (profile.role !== "BANK_OFFICER") {
    return errorResponse(
      403,
      "ERR_FORBIDDEN",
      "Only BANK_OFFICER accounts may register a lien lock."
    );
  }

  // --- Idempotent replay check ---
  const { data: existingKey } = await supabase
    .from("idempotency_keys")
    .select("response_status, response_body")
    .eq("key", idempotencyKey)
    .eq("endpoint", ENDPOINT_ID)
    .maybeSingle();

  if (existingKey) {
    return NextResponse.json(existingKey.response_body, { status: existingKey.response_status });
  }

  // --- Validate payload ---
  let payload: unknown;
  try {
    payload = await req.json();
  } catch {
    return errorResponse(400, "ERR_INVALID_PAYLOAD", "Request body must be valid JSON.");
  }

  const parsed = LienLockRequestSchema.safeParse(payload);
  if (!parsed.success) {
    return errorResponse(400, "ERR_INVALID_PAYLOAD", "Request failed schema validation.", parsed.error.issues);
  }
  const { spatial_id, loan_reference_no, facility_amount } = parsed.data;

  // --- Run the atomic lock via fn_lien_lock ---
  const { data: lockResult, error: lockError } = await supabase.rpc("fn_lien_lock", {
    p_spatial_id: spatial_id,
    p_loan_reference: loan_reference_no,
    p_facility_amount: facility_amount,
    p_bank_id: userData.user.id,
  });

  if (lockError) {
    const msg = lockError.message ?? "";
    let response: NextResponse<ApiErrorBody>;

    if (msg.includes("ERR_PARCEL_NOT_FOUND")) {
      response = errorResponse(404, "ERR_PARCEL_NOT_FOUND", `No parcel found for spatial_id ${spatial_id}.`);
    } else if (msg.includes("ERR_LIEN_LOCK_CONFLICT") || lockError.code === "23505") {
      response = errorResponse(
        409,
        "ERR_LIEN_LOCK_CONFLICT",
        "This parcel is already mortgage-locked, or this loan reference has already been used."
      );
    } else if (msg.includes("ERR_INVALID_PARCEL_STATE")) {
      response = errorResponse(
        422,
        "ERR_INVALID_PARCEL_STATE",
        "Only STATE_APPROVED parcels can be lien-locked."
      );
    } else {
      response = errorResponse(500, "ERR_LIEN_LOCK_FAILURE", "The lien lock could not be completed.");
    }

    // Persist the failure too — a retried Idempotency-Key should
    // replay the same outcome, not re-run the operation.
    await supabase.from("idempotency_keys").insert({
      key: idempotencyKey,
      endpoint: ENDPOINT_ID,
      response_status: response.status,
      response_body: await response.clone().json(),
    });

    return response;
  }

  const row = lockResult?.[0];
  const responseBody = {
    status: "success",
    message: `Lien registered against ${spatial_id}. Property status updated.`,
    new_property_status: row?.new_status ?? "MORTGAGE_LOCKED",
    registered_at: row?.registered_at,
  };

  await supabase.from("idempotency_keys").insert({
    key: idempotencyKey,
    endpoint: ENDPOINT_ID,
    response_status: 200,
    response_body: responseBody,
  });

  return NextResponse.json(responseBody, { status: 200 });
}
