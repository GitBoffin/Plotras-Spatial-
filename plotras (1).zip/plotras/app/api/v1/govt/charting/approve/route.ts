// =====================================================================
// PLOTRAS — POST /api/v1/govt/charting/approve
// =====================================================================
// PRD state diagram: [PENDING_CHARTING] --"State Surveyor-General /
// authorized agency approves survey and official charting"-->
// [STATE_APPROVED]. State-changing endpoint, so it follows the same
// Idempotency-Key discipline as lien-lock/discharge.
// =====================================================================

import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import { z } from "zod";

function getServiceClient() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { persistSession: false } }
  );
}

function errorResponse(status: number, code: string, message: string) {
  return NextResponse.json({ error: { code, message, timestamp: new Date().toISOString() } }, { status });
}

const RequestSchema = z.object({ spatial_id: z.string().min(1) });
const ENDPOINT_ID = "govt.charting-approve";

export async function POST(req: NextRequest) {
  const authHeader = req.headers.get("authorization");
  if (!authHeader?.startsWith("Bearer ")) {
    return errorResponse(401, "ERR_UNAUTHENTICATED", "Missing bearer token.");
  }
  const jwt = authHeader.slice("Bearer ".length);

  const idempotencyKey = req.headers.get("idempotency-key");
  if (!idempotencyKey || !z.string().uuid().safeParse(idempotencyKey).success) {
    return errorResponse(400, "ERR_MISSING_IDEMPOTENCY_KEY", "A UUID Idempotency-Key header is required.");
  }

  const supabase = getServiceClient();
  const { data: userData, error: userError } = await supabase.auth.getUser(jwt);
  if (userError || !userData.user) {
    return errorResponse(401, "ERR_UNAUTHENTICATED", "Invalid session.");
  }

  const { data: profile } = await supabase.from("users").select("role").eq("id", userData.user.id).single();
  if (profile?.role !== "GOVT_ADMIN") {
    return errorResponse(403, "ERR_FORBIDDEN", "Only GOVT_ADMIN accounts may approve state charting.");
  }

  const { data: existingKey } = await supabase
    .from("idempotency_keys")
    .select("response_status, response_body")
    .eq("key", idempotencyKey)
    .eq("endpoint", ENDPOINT_ID)
    .maybeSingle();
  if (existingKey) {
    return NextResponse.json(existingKey.response_body, { status: existingKey.response_status });
  }

  let payload: unknown;
  try {
    payload = await req.json();
  } catch {
    return errorResponse(400, "ERR_INVALID_PAYLOAD", "Request body must be valid JSON.");
  }
  const parsed = RequestSchema.safeParse(payload);
  if (!parsed.success) return errorResponse(400, "ERR_INVALID_PAYLOAD", "spatial_id is required.");

  const { data: result, error: approveError } = await supabase.rpc("fn_approve_charting", {
    p_spatial_id: parsed.data.spatial_id,
    p_caller_id: userData.user.id,
  });

  if (approveError) {
    const msg = approveError.message ?? "";
    let response: NextResponse;
    if (msg.includes("ERR_PARCEL_NOT_FOUND")) {
      response = errorResponse(404, "ERR_PARCEL_NOT_FOUND", `No parcel found for spatial_id ${parsed.data.spatial_id}.`);
    } else if (msg.includes("ERR_INVALID_PARCEL_STATE")) {
      response = errorResponse(422, "ERR_INVALID_PARCEL_STATE", "Only PENDING_CHARTING parcels can be approved this way.");
    } else {
      response = errorResponse(500, "ERR_CHARTING_APPROVAL_FAILURE", "Could not approve charting.");
    }
    await supabase.from("idempotency_keys").insert({
      key: idempotencyKey,
      endpoint: ENDPOINT_ID,
      response_status: response.status,
      response_body: await response.clone().json(),
    });
    return response;
  }

  const row = result?.[0];
  const responseBody = {
    status: "success",
    message: `${parsed.data.spatial_id} approved and charted. Status updated to STATE_APPROVED.`,
    new_property_status: row?.new_status ?? "STATE_APPROVED",
    approved_at: row?.approved_at,
  };

  await supabase.from("idempotency_keys").insert({
    key: idempotencyKey,
    endpoint: ENDPOINT_ID,
    response_status: 200,
    response_body: responseBody,
  });

  return NextResponse.json(responseBody, { status: 200 });
}
