// =====================================================================
// PLOTRAS — /api/v1/govt/zones
// =====================================================================
// Phase 3: "State master-layer management." Before this, the only way
// to add or change a govt_restricted_zones row was raw SQL (as in
// seed_demo.sql) — GOVT_ADMIN accounts had no actual UI/API path.
// GET is unauthenticated read (govt_zones_read_basic_signal RLS already
// lets any authenticated user read zones directly via Supabase — this
// GET exists for the admin UI's convenience, not because reads were
// otherwise blocked). POST/DELETE are GOVT_ADMIN-only, service-role
// writes, since govt_restricted_zones has no client-facing write policy.
// =====================================================================

import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import { z } from "zod";
import { signedRingArea, findSelfIntersection } from "@/lib/geometry/validatePolygon";

function getServiceClient() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { persistSession: false } }
  );
}

function errorResponse(status: number, code: string, message: string) {
  return NextResponse.json({ error: { code, message, timestamp: new Date().toISOString() } }, { status });
}

async function requireGovtAdmin(req: NextRequest) {
  const authHeader = req.headers.get("authorization");
  if (!authHeader?.startsWith("Bearer ")) return { error: errorResponse(401, "ERR_UNAUTHENTICATED", "Missing bearer token.") };
  const jwt = authHeader.slice("Bearer ".length);

  const supabase = getServiceClient();
  const { data: userData, error: userError } = await supabase.auth.getUser(jwt);
  if (userError || !userData.user) return { error: errorResponse(401, "ERR_UNAUTHENTICATED", "Invalid session.") };

  const { data: profile } = await supabase.from("users").select("role").eq("id", userData.user.id).single();
  if (profile?.role !== "GOVT_ADMIN") {
    return { error: errorResponse(403, "ERR_FORBIDDEN", "Only GOVT_ADMIN accounts may manage government zones.") };
  }
  return { supabase, userId: userData.user.id };
}

const PointSchema = z.object({ lat: z.number().gte(-90).lte(90), lng: z.number().gte(-180).lte(180) });
const CreateZoneSchema = z.object({
  zone_name: z.string().min(1),
  zone_type: z.string().min(1).default("GOVT_ACQUISITION"),
  source_authority: z.string().optional(),
  gazette_reference: z.string().optional(),
  points: z.array(PointSchema).min(3, "A zone polygon needs at least 3 points."),
});

export async function GET(req: NextRequest) {
  const ctx = await requireGovtAdmin(req);
  if ("error" in ctx) return ctx.error;

  const { data } = await ctx.supabase
    .from("govt_restricted_zones")
    .select("id, zone_name, zone_type, source_authority, gazette_reference, created_at")
    .order("created_at", { ascending: false });

  return NextResponse.json({ zones: data ?? [] });
}

export async function POST(req: NextRequest) {
  const ctx = await requireGovtAdmin(req);
  if ("error" in ctx) return ctx.error;

  let payload: unknown;
  try {
    payload = await req.json();
  } catch {
    return errorResponse(400, "ERR_INVALID_PAYLOAD", "Request body must be valid JSON.");
  }
  const parsed = CreateZoneSchema.safeParse(payload);
  if (!parsed.success) {
    return errorResponse(400, "ERR_INVALID_PAYLOAD", parsed.error.issues.map((i) => i.message).join("; "));
  }
  const { zone_name, zone_type, source_authority, gazette_reference, points } = parsed.data;

  if (signedRingArea(points) === 0) {
    return errorResponse(422, "ERR_DEGENERATE_POLYGON", "The submitted coordinates enclose zero area.");
  }
  const intersectionVertex = findSelfIntersection(points);
  if (intersectionVertex !== null) {
    return errorResponse(422, "ERR_SELF_INTERSECTING_POLYGON", "The coordinates form a self-intersecting polygon.");
  }

  const ring = [...points, points[0]]; // close the ring
  const geojson = {
    type: "Polygon",
    coordinates: [ring.map((p) => [p.lng, p.lat])],
  };

  const { data: zoneRow, error: rpcError } = await ctx.supabase.rpc("fn_create_govt_zone", {
    p_zone_name: zone_name,
    p_zone_type: zone_type,
    p_source_authority: source_authority ?? null,
    p_gazette_reference: gazette_reference ?? null,
    p_geojson: geojson,
  });

  if (rpcError || !zoneRow) {
    return errorResponse(500, "ERR_ZONE_CREATION_FAILED", "Could not create the zone.");
  }

  await ctx.supabase.from("audit_logs").insert({
    entity_type: "govt_restricted_zone",
    entity_id: zoneRow[0]?.id ?? ctx.userId,
    action: "ZONE_CREATED",
    performed_by: ctx.userId,
    new_state: { zone_name, zone_type, point_count: points.length },
  });

  return NextResponse.json({ zone: zoneRow[0] });
}

const DeleteZoneSchema = z.object({ zone_id: z.string().uuid() });

export async function DELETE(req: NextRequest) {
  const ctx = await requireGovtAdmin(req);
  if ("error" in ctx) return ctx.error;

  let payload: unknown;
  try {
    payload = await req.json();
  } catch {
    return errorResponse(400, "ERR_INVALID_PAYLOAD", "Request body must be valid JSON.");
  }
  const parsed = DeleteZoneSchema.safeParse(payload);
  if (!parsed.success) return errorResponse(400, "ERR_INVALID_PAYLOAD", "zone_id is required.");

  const { error } = await ctx.supabase.from("govt_restricted_zones").delete().eq("id", parsed.data.zone_id);
  if (error) return errorResponse(500, "ERR_ZONE_DELETE_FAILED", "Could not delete the zone.");

  await ctx.supabase.from("audit_logs").insert({
    entity_type: "govt_restricted_zone",
    entity_id: parsed.data.zone_id,
    action: "ZONE_DELETED",
    performed_by: ctx.userId,
  });

  return NextResponse.json({ deleted: true });
}
