// =====================================================================
// PLOTRAS — GET /api/v1/reports/certificate?token=<report_access_token>
// =====================================================================
// Renders the Spatial Clearance Certificate PDF from an EXISTING
// certificate record. It does not create that record itself in the
// normal path — the Paystack webhook does, asynchronously, right after
// marking payment SUCCESS (see lib/reports/certificateRecord.ts for why
// that satisfies PRD FR-004's async-generation-with-retry requirement).
// This route calls the same get-or-create helper only as a self-heal
// fallback for the rare case the webhook's attempt hasn't landed yet.
//
// PDF rendering itself is deterministic from the stored record, so
// re-downloading the same report always reproduces byte-identical
// content (same report_id, same hash) rather than minting a new
// certificate on every click.
//
// Font note: pdf-lib's built-in StandardFonts don't include Fraunces —
// embedding a real custom font requires @pdf-lib/fontkit plus shipping
// the .ttf file, which this route doesn't do. TimesRomanBold is used
// as the closest standard serif fallback for headings.
// =====================================================================

import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import { PDFDocument, StandardFonts, rgb } from "pdf-lib";
import QRCode from "qrcode";
import { signCertificate, type CertificateFields } from "@/lib/reports/sign";
import { getOrCreateCertificateRecord } from "@/lib/reports/certificateRecord";

const SIGNAL_RGB: Record<string, [number, number, number]> = {
  GREEN: [0.13, 0.77, 0.37],
  YELLOW: [0.92, 0.7, 0.03],
  RED: [0.94, 0.27, 0.27],
};

const SIGNAL_MEANING: Record<string, string> = {
  GREEN: "Clean Title — no coordinate collisions, no active liens, no government acquisition overlap.",
  YELLOW: "Active Bank Lien — this parcel currently secures an outstanding loan.",
  RED: "High Risk — this parcel overlaps another registered plot or a government acquisition zone.",
};

function getServiceClient() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { persistSession: false } }
  );
}

export async function GET(req: NextRequest) {
  const authHeader = req.headers.get("authorization");
  if (!authHeader?.startsWith("Bearer ")) {
    return NextResponse.json({ error: { code: "ERR_UNAUTHENTICATED", message: "Missing bearer token." } }, { status: 401 });
  }
  const jwt = authHeader.slice("Bearer ".length);

  const token = req.nextUrl.searchParams.get("token");
  if (!token) {
    return NextResponse.json({ error: { code: "ERR_INVALID_PAYLOAD", message: "Missing token." } }, { status: 400 });
  }

  const supabase = getServiceClient();
  const { data: userData, error: userError } = await supabase.auth.getUser(jwt);
  if (userError || !userData.user) {
    return NextResponse.json({ error: { code: "ERR_UNAUTHENTICATED", message: "Invalid session." } }, { status: 401 });
  }

  const { data: payment } = await supabase
    .from("payments")
    .select("status, spatial_id, user_id")
    .eq("report_access_token", token)
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();

  if (!payment || payment.user_id !== userData.user.id) {
    return NextResponse.json({ error: { code: "ERR_NOT_FOUND", message: "No report found for this token." } }, { status: 404 });
  }
  if (payment.status !== "SUCCESS") {
    return NextResponse.json(
      { error: { code: "ERR_REPORT_LOCKED", message: "This report has not been unlocked yet." } },
      { status: 402 }
    );
  }

  // Normally already created by the webhook, asynchronously. This call
  // is the self-heal path if that attempt hasn't landed yet, or failed.
  const cert = await getOrCreateCertificateRecord(supabase, token, payment.spatial_id);
  if (!cert) {
    return NextResponse.json(
      {
        error: {
          code: "ERR_REPORT_GENERATION_PENDING",
          message: "The certificate is still being generated. Try again shortly.",
        },
      },
      { status: 425 } // 425 Too Early
    );
  }

  const fields: CertificateFields = {
    spatial_id: cert.spatial_id,
    status: cert.status,
    signal: cert.signal,
    state_code: cert.state_code,
    lga: cert.lga,
    issued_at: cert.issued_at,
    report_access_token: cert.report_access_token,
  };
  const signature = signCertificate(fields);
  const documentHash = cert.sha256_hash;
  const reportId = cert.report_id;

  const appUrl = process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000";
  const verifyUrl = `${appUrl}/verify/${reportId}`;
  const qrPngDataUrl = await QRCode.toDataURL(verifyUrl, { margin: 1, width: 240 });
  const qrPngBytes = Buffer.from(qrPngDataUrl.split(",")[1], "base64");

  const pdf = await PDFDocument.create();
  const page = pdf.addPage([595.28, 841.89]); // A4
  const { width, height } = page.getSize();

  const serifBold = await pdf.embedFont(StandardFonts.TimesRomanBold);
  const serif = await pdf.embedFont(StandardFonts.TimesRoman);
  const sans = await pdf.embedFont(StandardFonts.Helvetica);

  const cream = rgb(0.98, 0.97, 0.94);
  const ink = rgb(0.12, 0.12, 0.12);
  const brass = rgb(0.71, 0.58, 0.35);
  const [sr, sg, sb] = SIGNAL_RGB[fields.signal];

  page.drawRectangle({ x: 0, y: 0, width, height, color: cream });
  page.drawRectangle({
    x: 24,
    y: 24,
    width: width - 48,
    height: height - 48,
    borderColor: brass,
    borderWidth: 1.5,
  });

  let y = height - 80;
  page.drawText("PLOTRAS", { x: 60, y, size: 14, font: sans, color: brass });
  page.drawText("Spatial Clearance Certificate", {
    x: 60,
    y: y - 30,
    size: 26,
    font: serifBold,
    color: ink,
  });

  y -= 70;
  page.drawRectangle({ x: 60, y: y - 8, width: width - 120, height: 36, color: rgb(sr, sg, sb) });
  page.drawText(`${fields.signal} — ${fields.status.replaceAll("_", " ")}`, {
    x: 72,
    y: y + 6,
    size: 13,
    font: serifBold,
    color: rgb(1, 1, 1),
  });

  y -= 60;
  const rows: [string, string][] = [
    ["Spatial ID", fields.spatial_id],
    ["State", fields.state_code],
    ["LGA", fields.lga],
    ["Issued", new Date(fields.issued_at).toUTCString()],
  ];
  for (const [label, value] of rows) {
    page.drawText(label, { x: 60, y, size: 10, font: sans, color: rgb(0.4, 0.4, 0.4) });
    page.drawText(value, { x: 220, y, size: 11, font: serif, color: ink });
    y -= 24;
  }

  y -= 20;
  page.drawText(SIGNAL_MEANING[fields.signal], {
    x: 60,
    y,
    size: 11,
    font: serif,
    color: ink,
    maxWidth: width - 120,
    lineHeight: 16,
  });

  // --- QR + hash verification block (PRD FR-003 / MVP Acceptance Gate) ---
  const qrImage = await pdf.embedPng(qrPngBytes);
  const qrSize = 90;
  const sigY = 130;

  page.drawLine({ start: { x: 60, y: sigY + 55 }, end: { x: width - 60, y: sigY + 55 }, thickness: 0.5, color: brass });

  page.drawImage(qrImage, { x: 60, y: sigY - 40, width: qrSize, height: qrSize });

  page.drawText("Scan to verify this certificate", {
    x: 60 + qrSize + 16,
    y: sigY + 30,
    size: 9,
    font: sans,
    color: rgb(0.4, 0.4, 0.4),
  });
  page.drawText(`Report ID: ${reportId}`, {
    x: 60 + qrSize + 16,
    y: sigY + 14,
    size: 8,
    font: sans,
    color: rgb(0.3, 0.3, 0.3),
  });
  page.drawText(`SHA-256: ${documentHash}`, {
    x: 60 + qrSize + 16,
    y: sigY,
    size: 7,
    font: sans,
    color: rgb(0.3, 0.3, 0.3),
    maxWidth: width - (60 + qrSize + 16) - 60,
    lineHeight: 9,
  });
  page.drawText(`${verifyUrl}`, {
    x: 60 + qrSize + 16,
    y: sigY - 24,
    size: 7,
    font: sans,
    color: brass,
  });
  page.drawText(
    `HMAC integrity signature: ${signature.slice(0, 48)}…`,
    { x: 60, y: sigY - 55, size: 7, font: sans, color: rgb(0.5, 0.5, 0.5), maxWidth: width - 120 }
  );
  page.drawText(
    "The SHA-256 hash and HMAC signature are integrity checks confirming this document was issued by Plotras and matches records on file — they are not a notarized or PKI-based legal signature.",
    { x: 60, y: sigY - 70, size: 7, font: sans, color: rgb(0.55, 0.55, 0.55), maxWidth: width - 120, lineHeight: 10 }
  );

  const pdfBytes = await pdf.save();

  await supabase.from("audit_logs").insert({
    entity_type: "certificate",
    entity_id: userData.user.id,
    action: "CERTIFICATE_DOWNLOADED",
    performed_by: userData.user.id,
    new_state: { spatial_id: fields.spatial_id, report_access_token: token, report_id: reportId },
  });

  return new NextResponse(Buffer.from(pdfBytes), {
    status: 200,
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="plotras-${fields.spatial_id}.pdf"`,
    },
  });
}
