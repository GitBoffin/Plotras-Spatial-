// =====================================================================
// PLOTRAS — GET /api/v1/reports/status?token=<report_access_token>
// =====================================================================
// The client polls this after launching Paystack Inline, since the
// webhook (which actually confirms payment) arrives out-of-band from
// the checkout popup's own success callback.
// =====================================================================

import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

export async function GET(req: NextRequest) {
  const token = req.nextUrl.searchParams.get("token");
  if (!token) {
    return NextResponse.json(
      { error: { code: "ERR_INVALID_PAYLOAD", message: "Missing token query param." } },
      { status: 400 }
    );
  }

  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { persistSession: false } }
  );

  const { data: payment } = await supabase
    .from("payments")
    .select("status")
    .eq("report_access_token", token)
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();

  return NextResponse.json({
    unlocked: payment?.status === "SUCCESS",
    status: payment?.status ?? "NOT_FOUND",
  });
}
