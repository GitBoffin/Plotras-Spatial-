// =====================================================================
// PLOTRAS — POST /api/v1/reports/unlock-intent
// =====================================================================
// Called when the user clicks "Unlock Full Report" on a verify result.
// Creates a PENDING row in `payments` and returns what the client needs
// to launch Paystack Inline. The webhook (webhooks/paystack/route.ts)
// is the only thing that ever flips a payment to SUCCESS — this route
// never does, so a client can't unlock a report just by calling it.
// =====================================================================

import { NextRequest, NextResponse } from "next/server";
import { createClient, SupabaseClient } from "@supabase/supabase-js";
import { z } from "zod";
import { randomUUID } from "crypto";

const UNLOCK_FEE_NAIRA = 2500; // must match app/api/v1/spatial/verify/route.ts

const RequestSchema = z.object({
  spatial_id: z.string().min(1),
  report_access_token: z.string().uuid(),
});

function getServiceClient(): SupabaseClient {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { persistSession: false } }
  );
}

function errorResponse(status: number, code: string, message: string) {
  return NextResponse.json(
    { error: { code, message, timestamp: new Date().toISOString() } },
    { status }
  );
}

export async function POST(req: NextRequest) {
  const authHeader = req.headers.get("authorization");
  if (!authHeader?.startsWith("Bearer ")) {
    return errorResponse(401, "ERR_UNAUTHENTICATED", "Missing or invalid bearer token.");
  }
  const jwt = authHeader.slice("Bearer ".length);

  const supabase = getServiceClient();
  const { data: userData, error: userError } = await supabase.auth.getUser(jwt);
  if (userError || !userData.user) {
    return errorResponse(401, "ERR_UNAUTHENTICATED", "Invalid or expired session.");
  }

  let payload: unknown;
  try {
    payload = await req.json();
  } catch {
    return errorResponse(400, "ERR_INVALID_PAYLOAD", "Request body must be valid JSON.");
  }

  const parsed = RequestSchema.safeParse(payload);
  if (!parsed.success) {
    return errorResponse(400, "ERR_INVALID_PAYLOAD", "Request failed schema validation.");
  }

  const { spatial_id, report_access_token } = parsed.data;
  const reference = `PLT-UNLOCK-${randomUUID().replace(/-/g, "").slice(0, 16).toUpperCase()}`;
  const amount_kobo = UNLOCK_FEE_NAIRA * 100;

  const { error: insertError } = await supabase.from("payments").insert({
    reference,
    report_access_token,
    spatial_id,
    user_id: userData.user.id,
    amount_kobo,
    status: "PENDING",
  });

  if (insertError) {
    return errorResponse(500, "ERR_PAYMENT_INTENT_FAILURE", "Could not start the unlock payment.");
  }

  return NextResponse.json({
    reference,
    amount_kobo,
    email: userData.user.email,
    public_key: process.env.NEXT_PUBLIC_PAYSTACK_PUBLIC_KEY ?? null,
  });
}
