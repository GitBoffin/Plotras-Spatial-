// =====================================================================
// PLOTRAS — POST /api/v1/reports/verify-signature
// =====================================================================
// Lets anyone holding a certificate confirm its HMAC integrity stamp
// hasn't been tampered with. Intentionally public (no auth) — that's
// the point of a verification endpoint referenced on a printed
// document. See lib/reports/sign.ts for what this signature is and
// isn't (an integrity check, not a legal PKI signature).
// =====================================================================

import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { verifyCertificateSignature, type CertificateFields } from "@/lib/reports/sign";

const RequestSchema = z.object({
  spatial_id: z.string(),
  status: z.string(),
  signal: z.enum(["GREEN", "YELLOW", "RED"]),
  state_code: z.string(),
  lga: z.string(),
  issued_at: z.string(),
  report_access_token: z.string(),
  signature: z.string(),
});

export async function POST(req: NextRequest) {
  let payload: unknown;
  try {
    payload = await req.json();
  } catch {
    return NextResponse.json({ valid: false, error: "Invalid JSON body." }, { status: 400 });
  }

  const parsed = RequestSchema.safeParse(payload);
  if (!parsed.success) {
    return NextResponse.json({ valid: false, error: "Missing or malformed fields." }, { status: 400 });
  }

  const { signature, ...fields } = parsed.data;
  const valid = verifyCertificateSignature(fields as CertificateFields, signature);

  return NextResponse.json({ valid });
}
