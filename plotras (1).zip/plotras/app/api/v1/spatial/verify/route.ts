// =====================================================================
// PLOTRAS — POST /api/v1/spatial/verify
// =====================================================================
// Consumer-facing endpoint. Auth: JWT/session. Rate limit: 10/min/IP
// (PRD Section 4, "Consumer APIs"). Previously this file said rate
// limiting was intentionally left out "to avoid a false sense of
// protection from a single-instance counter" — that reasoning doesn't
// hold once there's a real shared counter (fn_rate_limit_check, backed
// by Postgres rather than in-process memory), so it's implemented now.
//
// Core validation/collision/signal logic lives in
// lib/verify/runSpatialVerification.ts, shared with the B2B endpoint
// (app/api/v1/b2b/title-verification) so the two can't silently drift
// apart on business logic — only auth and rate limiting differ.
// =====================================================================

import { NextRequest, NextResponse } from "next/server";
import { createClient, SupabaseClient } from "@supabase/supabase-js";
import { randomUUID } from "crypto";
import { VerifyRequestSchema, runSpatialVerification } from "@/lib/verify/runSpatialVerification";

interface ApiErrorBody {
  error: { code: string; message: string; details?: unknown[]; timestamp: string };
}

function errorResponse(status: number, code: string, message: string, details?: unknown[]): NextResponse<ApiErrorBody> {
  return NextResponse.json(
    { error: { code, message, ...(details ? { details } : {}), timestamp: new Date().toISOString() } },
    { status }
  );
}

function getServiceClient(): SupabaseClient {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { persistSession: false } }
  );
}

const CONSUMER_RATE_LIMIT_PER_MINUTE = 10; // PRD example limit

export async function POST(req: NextRequest) {
  const authHeader = req.headers.get("authorization");
  if (!authHeader?.startsWith("Bearer ")) {
    return errorResponse(401, "ERR_UNAUTHENTICATED", "Missing or invalid bearer token.");
  }

  const supabase = getServiceClient();

  const clientIp = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown";
  const { data: withinLimit } = await supabase.rpc("fn_rate_limit_check", {
    p_bucket_key: `ip:${clientIp}:spatial.verify`,
    p_limit: CONSUMER_RATE_LIMIT_PER_MINUTE,
    p_window_seconds: 60,
  });
  if (withinLimit === false) {
    return errorResponse(429, "ERR_RATE_LIMIT_EXCEEDED", `Rate limit of ${CONSUMER_RATE_LIMIT_PER_MINUTE} requests/minute/IP exceeded.`);
  }

  let payload: unknown;
  try {
    payload = await req.json();
  } catch {
    return errorResponse(400, "ERR_INVALID_PAYLOAD", "Request body must be valid JSON.");
  }

  const parsed = VerifyRequestSchema.safeParse(payload);
  if (!parsed.success) {
    return errorResponse(400, "ERR_INVALID_PAYLOAD", "Request failed schema validation.", parsed.error.issues);
  }

  const result = await runSpatialVerification(supabase, parsed.data.beacons);

  if (!result.ok) {
    return errorResponse(result.status, result.code, result.message, result.details);
  }

  await supabase.from("audit_logs").insert({
    entity_type: "spatial_verification",
    entity_id: randomUUID(),
    action: "SPATIAL_VERIFY",
    ip_address: clientIp === "unknown" ? null : clientIp,
    previous_state: null,
    new_state: {
      search_mode: "BEACONS",
      beacon_count: result.auditContext.beaconCount,
      source_srid: result.auditContext.sourceSrid,
      target_srid: result.auditContext.targetSrid,
      result: result.data,
    },
  });

  return NextResponse.json({ status: "success", data: result.data }, { status: 200 });
}
