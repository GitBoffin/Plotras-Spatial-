// =====================================================================
// PLOTRAS — POST /api/v1/survey/submit
// =====================================================================
// RBAC matrix: "Upload draft beacon survey" — SURVEYOR and GOVT_ADMIN
// only. Creates a new parcel at DRAFT_SURVEY, auto-advancing to
// PENDING_CHARTING if automated spatial validation passes (see
// fn_submit_draft_survey for what that means and the judgment call
// behind it).
// =====================================================================

import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import { z } from "zod";
import { BeaconSchema } from "@/lib/verify/runSpatialVerification";

function getServiceClient() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { persistSession: false } }
  );
}

function errorResponse(status: number, code: string, message: string) {
  return NextResponse.json({ error: { code, message, timestamp: new Date().toISOString() } }, { status });
}

const RequestSchema = z.object({
  beacons: z.array(BeaconSchema).min(4),
  state_code: z.string().min(1),
  lga: z.string().min(1),
  title_type: z.string().optional(),
});

export async function POST(req: NextRequest) {
  const authHeader = req.headers.get("authorization");
  if (!authHeader?.startsWith("Bearer ")) return errorResponse(401, "ERR_UNAUTHENTICATED", "Missing bearer token.");
  const jwt = authHeader.slice("Bearer ".length);

  const supabase = getServiceClient();
  const { data: userData, error: userError } = await supabase.auth.getUser(jwt);
  if (userError || !userData.user) return errorResponse(401, "ERR_UNAUTHENTICATED", "Invalid session.");

  const { data: profile } = await supabase.from("users").select("role").eq("id", userData.user.id).single();
  if (profile?.role !== "SURVEYOR" && profile?.role !== "GOVT_ADMIN") {
    return errorResponse(403, "ERR_FORBIDDEN", "Only SURVEYOR or GOVT_ADMIN accounts may submit a draft survey.");
  }

  let payload: unknown;
  try {
    payload = await req.json();
  } catch {
    return errorResponse(400, "ERR_INVALID_PAYLOAD", "Request body must be valid JSON.");
  }
  const parsed = RequestSchema.safeParse(payload);
  if (!parsed.success) {
    return errorResponse(400, "ERR_INVALID_PAYLOAD", "Request failed schema validation.");
  }

  const { beacons, state_code, lga, title_type } = parsed.data;

  const { data: result, error: rpcError } = await supabase.rpc("fn_submit_draft_survey", {
    p_beacon_points: beacons.map((b) => ({ lat: b.lat, lng: b.lng })),
    p_state_code: state_code,
    p_lga: lga,
    p_title_type: title_type ?? null,
    p_caller_id: userData.user.id,
  });

  if (rpcError) {
    const msg = rpcError.message ?? "";
    if (msg.includes("ERR_INVALID_GEOMETRY_MIN_BEACONS")) {
      return errorResponse(422, "ERR_INVALID_GEOMETRY_MIN_BEACONS", "At least 4 beacons are required.");
    }
    if (msg.includes("ERR_SELF_INTERSECTING_POLYGON")) {
      return errorResponse(422, "ERR_SELF_INTERSECTING_POLYGON", "The submitted coordinates form a self-intersecting polygon.");
    }
    if (msg.includes("ERR_DEGENERATE_POLYGON")) {
      return errorResponse(422, "ERR_DEGENERATE_POLYGON", "The submitted coordinates enclose zero area.");
    }
    return errorResponse(500, "ERR_SURVEY_SUBMISSION_FAILED", "Could not submit the draft survey.");
  }

  const row = result?.[0];
  return NextResponse.json({
    status: "success",
    spatial_id: row?.spatial_id,
    parcel_status: row?.status,
    validation_passed: row?.validation_passed,
    validation_note: row?.validation_note,
  });
}
