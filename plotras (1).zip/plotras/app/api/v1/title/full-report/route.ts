// =====================================================================
// PLOTRAS — GET /api/v1/title/full-report?spatial_id=<id>
// =====================================================================
// Phase 2 scope: "Full title reports." Distinct from the consumer
// Spatial Clearance Certificate (app/api/v1/reports/certificate),
// which is a lightweight, payment-gated, QR-verifiable snapshot for a
// retail buyer. This is the institutional document: full chronological
// lineage + current parcel/lien detail in one PDF, for the three roles
// the RBAC matrix already gives unconditional (non-"Paid") access to
// lineage and full-report unlock: LAWYER, BANK_OFFICER, GOVT_ADMIN.
//
// Deliberately NOT wired into the payment/certificates/QR-verification
// system — that machinery exists to let a stranger verify a document a
// retail buyer is holding. This report is for a professional who
// already has an authenticated Plotras session; there's no equivalent
// "stranger holding a printout" scenario to design for here.
// =====================================================================

import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import { PDFDocument, StandardFonts, rgb } from "pdf-lib";

const SIGNAL_RGB: Record<string, [number, number, number]> = {
  GREEN: [0.13, 0.77, 0.37],
  YELLOW: [0.92, 0.7, 0.03],
  RED: [0.94, 0.27, 0.27],
};

const EVENT_LABELS: Record<string, string> = {
  PARCEL_REGISTERED: "Root of Title — Parcel Registered",
  TITLE_TRANSFER: "Title Transfer",
  LIEN_REGISTERED: "Mortgage Lien Locked",
  LIEN_DISCHARGED: "Lien Discharged",
};

function getServiceClient() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { persistSession: false } }
  );
}

function errorResponse(status: number, code: string, message: string) {
  return NextResponse.json({ error: { code, message, timestamp: new Date().toISOString() } }, { status });
}

export async function GET(req: NextRequest) {
  const authHeader = req.headers.get("authorization");
  if (!authHeader?.startsWith("Bearer ")) return errorResponse(401, "ERR_UNAUTHENTICATED", "Missing bearer token.");
  const jwt = authHeader.slice("Bearer ".length);

  const spatialId = req.nextUrl.searchParams.get("spatial_id");
  if (!spatialId) return errorResponse(400, "ERR_INVALID_PAYLOAD", "Missing spatial_id query param.");

  const supabase = getServiceClient();
  const { data: userData, error: userError } = await supabase.auth.getUser(jwt);
  if (userError || !userData.user) return errorResponse(401, "ERR_UNAUTHENTICATED", "Invalid session.");

  const { data: profile } = await supabase.from("users").select("role").eq("id", userData.user.id).single();
  if (!profile || !["LAWYER", "BANK_OFFICER", "GOVT_ADMIN"].includes(profile.role)) {
    return errorResponse(403, "ERR_FORBIDDEN", "Full title reports are only available to LAWYER, BANK_OFFICER, or GOVT_ADMIN accounts.");
  }

  const { data: parcel } = await supabase
    .from("parcels")
    .select("spatial_id, status, state_code, lga, title_type, created_at")
    .eq("spatial_id", spatialId)
    .maybeSingle();
  if (!parcel) return errorResponse(404, "ERR_PARCEL_NOT_FOUND", `No parcel found for spatial_id ${spatialId}.`);

  const { data: summaryRows } = await supabase.rpc("fn_parcel_summary", { p_spatial_id: spatialId });
  const signal = (summaryRows?.[0]?.signal ?? "GREEN") as "GREEN" | "YELLOW" | "RED";

  const { data: lineage, error: lineageError } = await supabase.rpc("fn_title_lineage", {
    p_spatial_id: spatialId,
    p_include_sensitive: true, // these three roles always get full detail
  });
  if (lineageError) return errorResponse(500, "ERR_LINEAGE_FAILURE", "Could not retrieve title lineage.");

  // --- Build the PDF ---
  const pdf = await PDFDocument.create();
  let page = pdf.addPage([595.28, 841.89]);
  const { width, height } = page.getSize();

  const serifBold = await pdf.embedFont(StandardFonts.TimesRomanBold);
  const serif = await pdf.embedFont(StandardFonts.TimesRoman);
  const sans = await pdf.embedFont(StandardFonts.Helvetica);

  const cream = rgb(0.98, 0.97, 0.94);
  const ink = rgb(0.12, 0.12, 0.12);
  const brass = rgb(0.71, 0.58, 0.35);
  const muted = rgb(0.45, 0.45, 0.45);

  const margin = 56;
  let y = height - 70;

  function newPageIfNeeded(spaceNeeded: number) {
    if (y - spaceNeeded < margin + 40) {
      page = pdf.addPage([595.28, 841.89]);
      page.drawRectangle({ x: 0, y: 0, width, height, color: cream });
      y = height - 70;
    }
  }

  page.drawRectangle({ x: 0, y: 0, width, height, color: cream });

  page.drawText("PLOTRAS", { x: margin, y, size: 12, font: sans, color: brass });
  page.drawText("Full Title Report", { x: margin, y: y - 26, size: 22, font: serifBold, color: ink });
  y -= 60;

  const [sr, sg, sb] = SIGNAL_RGB[signal];
  page.drawRectangle({ x: margin, y: y - 8, width: width - margin * 2, height: 32, color: rgb(sr, sg, sb) });
  page.drawText(`${signal} — ${parcel.status.replaceAll("_", " ")}`, {
    x: margin + 12, y: y + 4, size: 12, font: serifBold, color: rgb(1, 1, 1),
  });
  y -= 50;

  const fields: [string, string][] = [
    ["Spatial ID", parcel.spatial_id],
    ["State / LGA", `${parcel.lga}, ${parcel.state_code}`],
    ["Title type", parcel.title_type ?? "Not yet on file"],
    ["Registered", new Date(parcel.created_at).toUTCString()],
    ["Report generated", new Date().toUTCString()],
    ["Prepared for", `${profile.role} (Plotras account ${userData.user.email ?? userData.user.id})`],
  ];
  for (const [label, value] of fields) {
    page.drawText(label, { x: margin, y, size: 9, font: sans, color: muted });
    page.drawText(value, { x: margin + 150, y, size: 10, font: serif, color: ink });
    y -= 20;
  }

  y -= 20;
  page.drawLine({ start: { x: margin, y }, end: { x: width - margin, y }, thickness: 0.75, color: brass });
  y -= 30;
  page.drawText("Chronological Chain of Title", { x: margin, y, size: 14, font: serifBold, color: ink });
  y -= 30;

  const events = (lineage ?? []) as { event_type: string; event_date: string; details: Record<string, unknown> }[];
  if (events.length === 0) {
    page.drawText("No events on file for this parcel.", { x: margin, y, size: 10, font: serif, color: muted });
    y -= 20;
  }

  for (const ev of events) {
    newPageIfNeeded(70);
    page.drawText(EVENT_LABELS[ev.event_type] ?? ev.event_type, { x: margin, y, size: 11, font: serifBold, color: ink });
    y -= 16;
    page.drawText(ev.event_date ? new Date(ev.event_date).toUTCString() : "Date unavailable", {
      x: margin, y, size: 8, font: sans, color: muted,
    });
    y -= 16;
    for (const [k, v] of Object.entries(ev.details)) {
      newPageIfNeeded(14);
      page.drawText(`${k.replaceAll("_", " ")}: ${String(v ?? "—")}`, { x: margin + 12, y, size: 8, font: sans, color: muted });
      y -= 13;
    }
    y -= 12;
  }

  const pdfBytes = await pdf.save();

  await supabase.from("audit_logs").insert({
    entity_type: "parcel",
    entity_id: userData.user.id,
    action: "FULL_TITLE_REPORT_GENERATED",
    performed_by: userData.user.id,
    new_state: { spatial_id: parcel.spatial_id },
  });

  return new NextResponse(Buffer.from(pdfBytes), {
    status: 200,
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="plotras-full-report-${parcel.spatial_id}.pdf"`,
    },
  });
}
