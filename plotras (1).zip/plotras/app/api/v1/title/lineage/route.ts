// =====================================================================
// PLOTRAS — GET /api/v1/title/lineage?spatial_id=<id>
// =====================================================================
// PRD FR-006 + RBAC matrix row "View ownership lineage":
//   RETAIL_USER: ❌     SURVEYOR: Limited     LAWYER/BANK_OFFICER/GOVT_ADMIN: ✅
//
// "Limited" is not defined further anywhere in the PRD. Judgment call,
// stated plainly rather than silently assumed: a surveyor can see that
// a parcel has a registration and transfer/lien HISTORY (useful for
// confirming survey provenance) without seeing transfer parties, loan
// references, or lien amounts — those are financial/legal specifics a
// surveyor has no professional need for. Implemented by the
// p_include_sensitive flag on fn_title_lineage.
// =====================================================================

import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

function errorResponse(status: number, code: string, message: string) {
  return NextResponse.json(
    { error: { code, message, timestamp: new Date().toISOString() } },
    { status }
  );
}

export async function GET(req: NextRequest) {
  const authHeader = req.headers.get("authorization");
  if (!authHeader?.startsWith("Bearer ")) {
    return errorResponse(401, "ERR_UNAUTHENTICATED", "Missing or invalid bearer token.");
  }
  const jwt = authHeader.slice("Bearer ".length);

  const spatialId = req.nextUrl.searchParams.get("spatial_id");
  if (!spatialId) {
    return errorResponse(400, "ERR_INVALID_PAYLOAD", "Missing spatial_id query param.");
  }

  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { persistSession: false } }
  );

  const { data: userData, error: userError } = await supabase.auth.getUser(jwt);
  if (userError || !userData.user) {
    return errorResponse(401, "ERR_UNAUTHENTICATED", "Invalid or expired session.");
  }

  const { data: profile } = await supabase
    .from("users")
    .select("role")
    .eq("id", userData.user.id)
    .single();

  const role = profile?.role;

  if (!role || role === "RETAIL_USER") {
    return errorResponse(
      403,
      "ERR_FORBIDDEN",
      "Title lineage is not available to RETAIL_USER accounts. Unlock a report from /verify for a summary view instead."
    );
  }

  const includeSensitive = role !== "SURVEYOR"; // SURVEYOR = "Limited" per RBAC matrix

  const { data: lineage, error: lineageError } = await supabase.rpc("fn_title_lineage", {
    p_spatial_id: spatialId,
    p_include_sensitive: includeSensitive,
  });

  if (lineageError) {
    if (lineageError.message?.includes("ERR_PARCEL_NOT_FOUND")) {
      return errorResponse(404, "ERR_PARCEL_NOT_FOUND", `No parcel found for spatial_id ${spatialId}.`);
    }
    return errorResponse(500, "ERR_LINEAGE_FAILURE", "Could not retrieve title lineage.");
  }

  await supabase.from("audit_logs").insert({
    entity_type: "parcel",
    entity_id: userData.user.id,
    action: "TITLE_LINEAGE_VIEWED",
    performed_by: userData.user.id,
    new_state: { spatial_id: spatialId, limited: !includeSensitive },
  });

  return NextResponse.json({ spatial_id: spatialId, limited: !includeSensitive, events: lineage ?? [] });
}
