// =====================================================================
// PLOTRAS — POST /api/v1/title/transfer/initiate
// =====================================================================
// PRD state diagram: [STATE_APPROVED] --"Deed of Assignment + required
// consent/registration successfully processed"--> [TRANSFERRED]. This
// route only INITIATES (creates a PENDING title_transfers row) — the
// actual parcel status change happens on GOVT_ADMIN approval (see
// /api/v1/title/transfer/review), matching the RBAC matrix's "Approve
// title transfer" row (GOVT_ADMIN only).
//
// RBAC judgment call (documented in the migration too): the matrix has
// no "initiate transfer" row, only "approve." LAWYER initiates here as
// the closest fit to real conveyancing practice.
// =====================================================================

import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import { z } from "zod";

function getServiceClient() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { persistSession: false } }
  );
}

function errorResponse(status: number, code: string, message: string) {
  return NextResponse.json({ error: { code, message, timestamp: new Date().toISOString() } }, { status });
}

const RequestSchema = z.object({
  spatial_id: z.string().min(1),
  assignee_email: z.string().email(),
  instrument_type: z.string().min(1),
  gov_registry_vol: z.string().optional(),
  gov_registry_page: z.string().optional(),
});

export async function POST(req: NextRequest) {
  const authHeader = req.headers.get("authorization");
  if (!authHeader?.startsWith("Bearer ")) return errorResponse(401, "ERR_UNAUTHENTICATED", "Missing bearer token.");
  const jwt = authHeader.slice("Bearer ".length);

  const supabase = getServiceClient();
  const { data: userData, error: userError } = await supabase.auth.getUser(jwt);
  if (userError || !userData.user) return errorResponse(401, "ERR_UNAUTHENTICATED", "Invalid session.");

  const { data: profile } = await supabase.from("users").select("role").eq("id", userData.user.id).single();
  if (profile?.role !== "LAWYER") {
    return errorResponse(403, "ERR_FORBIDDEN", "Only LAWYER accounts may initiate a title transfer.");
  }

  let payload: unknown;
  try {
    payload = await req.json();
  } catch {
    return errorResponse(400, "ERR_INVALID_PAYLOAD", "Request body must be valid JSON.");
  }
  const parsed = RequestSchema.safeParse(payload);
  if (!parsed.success) return errorResponse(400, "ERR_INVALID_PAYLOAD", "Request failed schema validation.");

  const { spatial_id, assignee_email, instrument_type, gov_registry_vol, gov_registry_page } = parsed.data;

  const { data: assignee } = await supabase.from("users").select("id").eq("email", assignee_email).maybeSingle();
  if (!assignee) {
    return errorResponse(404, "ERR_ASSIGNEE_NOT_FOUND", `No Plotras account found for ${assignee_email}. They must sign up first.`);
  }

  const { data: result, error: rpcError } = await supabase.rpc("fn_initiate_title_transfer", {
    p_spatial_id: spatial_id,
    p_assignee_id: assignee.id,
    p_instrument_type: instrument_type,
    p_gov_registry_vol: gov_registry_vol ?? null,
    p_gov_registry_page: gov_registry_page ?? null,
    p_caller_id: userData.user.id,
  });

  if (rpcError) {
    const msg = rpcError.message ?? "";
    if (msg.includes("ERR_PARCEL_NOT_FOUND")) return errorResponse(404, "ERR_PARCEL_NOT_FOUND", `No parcel found for spatial_id ${spatial_id}.`);
    if (msg.includes("ERR_INVALID_PARCEL_STATE")) {
      return errorResponse(422, "ERR_INVALID_PARCEL_STATE", "Transfers require a STATE_APPROVED parcel with no active lien.");
    }
    if (msg.includes("ERR_TRANSFER_ALREADY_PENDING")) {
      return errorResponse(409, "ERR_TRANSFER_ALREADY_PENDING", "A transfer is already pending review for this parcel.");
    }
    return errorResponse(500, "ERR_TRANSFER_INITIATION_FAILED", "Could not initiate the title transfer.");
  }

  const row = result?.[0];
  return NextResponse.json({
    status: "success",
    message: `Transfer of ${spatial_id} to ${assignee_email} submitted for government approval.`,
    transfer_id: row?.transfer_id,
    transfer_status: row?.status,
  });
}
