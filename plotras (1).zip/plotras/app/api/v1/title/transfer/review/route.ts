// =====================================================================
// PLOTRAS — POST /api/v1/title/transfer/review
// =====================================================================
// RBAC matrix: "Approve title transfer" — GOVT_ADMIN only. State-
// changing, so it follows the same Idempotency-Key discipline as
// lien-lock/discharge/charting-approval.
// =====================================================================

import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import { z } from "zod";

function getServiceClient() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { persistSession: false } }
  );
}

function errorResponse(status: number, code: string, message: string) {
  return NextResponse.json({ error: { code, message, timestamp: new Date().toISOString() } }, { status });
}

const RequestSchema = z.object({ transfer_id: z.string().uuid(), approve: z.boolean() });
const ENDPOINT_ID = "title.transfer-review";

export async function POST(req: NextRequest) {
  const authHeader = req.headers.get("authorization");
  if (!authHeader?.startsWith("Bearer ")) return errorResponse(401, "ERR_UNAUTHENTICATED", "Missing bearer token.");
  const jwt = authHeader.slice("Bearer ".length);

  const idempotencyKey = req.headers.get("idempotency-key");
  if (!idempotencyKey || !z.string().uuid().safeParse(idempotencyKey).success) {
    return errorResponse(400, "ERR_MISSING_IDEMPOTENCY_KEY", "A UUID Idempotency-Key header is required.");
  }

  const supabase = getServiceClient();
  const { data: userData, error: userError } = await supabase.auth.getUser(jwt);
  if (userError || !userData.user) return errorResponse(401, "ERR_UNAUTHENTICATED", "Invalid session.");

  const { data: profile } = await supabase.from("users").select("role").eq("id", userData.user.id).single();
  if (profile?.role !== "GOVT_ADMIN") {
    return errorResponse(403, "ERR_FORBIDDEN", "Only GOVT_ADMIN accounts may approve or reject a title transfer.");
  }

  const { data: existingKey } = await supabase
    .from("idempotency_keys")
    .select("response_status, response_body")
    .eq("key", idempotencyKey)
    .eq("endpoint", ENDPOINT_ID)
    .maybeSingle();
  if (existingKey) return NextResponse.json(existingKey.response_body, { status: existingKey.response_status });

  let payload: unknown;
  try {
    payload = await req.json();
  } catch {
    return errorResponse(400, "ERR_INVALID_PAYLOAD", "Request body must be valid JSON.");
  }
  const parsed = RequestSchema.safeParse(payload);
  if (!parsed.success) return errorResponse(400, "ERR_INVALID_PAYLOAD", "transfer_id and approve are required.");

  const { data: result, error: rpcError } = await supabase.rpc("fn_review_title_transfer", {
    p_transfer_id: parsed.data.transfer_id,
    p_approve: parsed.data.approve,
    p_caller_id: userData.user.id,
  });

  if (rpcError) {
    const msg = rpcError.message ?? "";
    let response: NextResponse;
    if (msg.includes("ERR_TRANSFER_NOT_FOUND")) response = errorResponse(404, "ERR_TRANSFER_NOT_FOUND", "No such title transfer.");
    else if (msg.includes("ERR_ALREADY_REVIEWED")) response = errorResponse(409, "ERR_ALREADY_REVIEWED", "This transfer was already reviewed.");
    else if (msg.includes("ERR_INVALID_PARCEL_STATE")) response = errorResponse(422, "ERR_INVALID_PARCEL_STATE", "Parcel is no longer eligible (e.g. a lien was locked since initiation).");
    else response = errorResponse(500, "ERR_TRANSFER_REVIEW_FAILED", "Could not review the title transfer.");

    await supabase.from("idempotency_keys").insert({
      key: idempotencyKey, endpoint: ENDPOINT_ID,
      response_status: response.status, response_body: await response.clone().json(),
    });
    return response;
  }

  const row = result?.[0];
  const responseBody = {
    status: "success",
    transfer_status: row?.new_status,
    parcel_status: row?.parcel_status,
  };

  await supabase.from("idempotency_keys").insert({
    key: idempotencyKey, endpoint: ENDPOINT_ID, response_status: 200, response_body: responseBody,
  });

  return NextResponse.json(responseBody);
}
