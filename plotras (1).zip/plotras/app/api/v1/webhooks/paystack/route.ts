// =====================================================================
// PLOTRAS — POST /api/v1/webhooks/paystack
// =====================================================================
// PRD: "verify the signature, validate the transaction reference and
// amount, enforce idempotency, and only then unlock [the report]."
//
// Paystack signs the raw request body with HMAC-SHA512 using your
// secret key, sent as the x-paystack-signature header. This MUST be
// computed over the raw bytes, before any JSON parsing — parsing first
// and re-serializing can change whitespace/key order and silently
// break signature verification.
//
// Paystack expects a fast 200 response regardless of internal outcome
// (a non-2xx makes it retry the webhook); real failures are recorded
// in audit_logs / payments.status rather than surfaced via HTTP status.
// =====================================================================

import { NextRequest, NextResponse } from "next/server";
import { createClient, SupabaseClient } from "@supabase/supabase-js";
import { createHmac, timingSafeEqual } from "crypto";
import { getOrCreateCertificateRecord } from "@/lib/reports/certificateRecord";

function getServiceClient(): SupabaseClient {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { persistSession: false } }
  );
}

function verifySignature(rawBody: string, signature: string | null): boolean {
  if (!signature) return false;
  const secret = process.env.PAYSTACK_SECRET_KEY;
  if (!secret) return false;

  const expected = createHmac("sha512", secret).update(rawBody).digest("hex");

  const expectedBuf = Buffer.from(expected, "utf8");
  const givenBuf = Buffer.from(signature, "utf8");
  if (expectedBuf.length !== givenBuf.length) return false;

  return timingSafeEqual(expectedBuf, givenBuf);
}

export async function POST(req: NextRequest) {
  const rawBody = await req.text();
  const signature = req.headers.get("x-paystack-signature");

  if (!verifySignature(rawBody, signature)) {
    // Deliberately vague — don't tell an attacker which part failed.
    return NextResponse.json({ received: false }, { status: 401 });
  }

  let event: any;
  try {
    event = JSON.parse(rawBody);
  } catch {
    return NextResponse.json({ received: false }, { status: 400 });
  }

  const supabase = getServiceClient();

  if (event.event !== "charge.success") {
    // Acknowledge and ignore — we only act on successful charges.
    return NextResponse.json({ received: true });
  }

  const reference: string | undefined = event.data?.reference;
  const amount: number | undefined = event.data?.amount;

  if (!reference || typeof amount !== "number") {
    return NextResponse.json({ received: true });
  }

  const { data: payment } = await supabase
    .from("payments")
    .select("id, status, amount_kobo, spatial_id, user_id, report_access_token")
    .eq("reference", reference)
    .maybeSingle();

  if (!payment) {
    // Unknown reference — not one of ours, or a stale/test event.
    return NextResponse.json({ received: true });
  }

  // Idempotency: Paystack can and does deliver the same webhook more
  // than once. A payment already marked SUCCESS is not reprocessed.
  if (payment.status === "SUCCESS") {
    return NextResponse.json({ received: true, idempotent_replay: true });
  }

  if (amount !== payment.amount_kobo) {
    await supabase.from("payments").update({ status: "FAILED" }).eq("id", payment.id);
    await supabase.from("audit_logs").insert({
      entity_type: "payment",
      entity_id: payment.id,
      action: "PAYMENT_AMOUNT_MISMATCH",
      new_state: { expected_kobo: payment.amount_kobo, received_kobo: amount, reference },
    });
    return NextResponse.json({ received: true });
  }

  await supabase
    .from("payments")
    .update({ status: "SUCCESS", paid_at: new Date().toISOString() })
    .eq("id", payment.id);

  await supabase.from("audit_logs").insert({
    entity_type: "payment",
    entity_id: payment.id,
    action: "REPORT_UNLOCKED",
    performed_by: payment.user_id,
    new_state: { spatial_id: payment.spatial_id, reference },
  });

  // PRD FR-004: "Report generation occurs asynchronously where
  // necessary." This runs right here, decoupled from whatever request
  // the buyer's browser makes — the certificate download route
  // (app/api/v1/reports/certificate) will find this record already
  // waiting, or self-heal by calling the same function if this attempt
  // failed for any reason. Either way payment.status above is already
  // committed and cannot be rolled back by a report-generation failure.
  try {
    await getOrCreateCertificateRecord(supabase, payment.report_access_token, payment.spatial_id);
  } catch (err) {
    await supabase.from("audit_logs").insert({
      entity_type: "payment",
      entity_id: payment.id,
      action: "CERTIFICATE_RECORD_GENERATION_FAILED",
      new_state: { error: err instanceof Error ? err.message : String(err) },
    });
    // Deliberately not re-thrown — Paystack still gets its 200, and the
    // certificate route's own get-or-create call is the retry path.
  }

  return NextResponse.json({ received: true });
}
