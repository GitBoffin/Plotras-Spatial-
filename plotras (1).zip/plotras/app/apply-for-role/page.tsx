import ApplyForRoleForm from "@/components/auth/ApplyForRoleForm";
import SiteHeader from "@/components/layout/SiteHeader";

export default function ApplyForRolePage() {
  return (
    <main className="min-h-screen bg-canvas">
      <SiteHeader />
      <ApplyForRoleForm />
    </main>
  );
}
