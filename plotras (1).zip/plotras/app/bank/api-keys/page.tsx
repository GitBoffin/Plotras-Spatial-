import ApiKeysManager from "@/components/bank/ApiKeysManager";
import SiteHeader from "@/components/layout/SiteHeader";

export default function ApiKeysPage() {
  return (
    <main className="min-h-screen bg-canvas">
      <SiteHeader />
      <ApiKeysManager />
    </main>
  );
}
