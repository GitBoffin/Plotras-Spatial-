import BankDashboard from "@/components/bank/BankDashboard";
import SiteHeader from "@/components/layout/SiteHeader";

export default function BankDashboardPage() {
  return (
    <main className="min-h-screen bg-canvas">
      <SiteHeader />
      <BankDashboard />
    </main>
  );
}
