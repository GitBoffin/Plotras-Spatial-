import LienLockForm from "@/components/bank/LienLockForm";
import LienDischargeForm from "@/components/bank/LienDischargeForm";
import SiteHeader from "@/components/layout/SiteHeader";

export default function LienLockPage() {
  return (
    <main className="min-h-screen bg-canvas">
      <SiteHeader />
      <LienLockForm />
      <div className="mx-auto max-w-lg px-6">
        <LienDischargeForm />
      </div>
    </main>
  );
}
