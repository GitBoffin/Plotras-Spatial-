import TitleTransferForm from "@/components/legal/TitleTransferForm";
import SiteHeader from "@/components/layout/SiteHeader";

export default function TitleTransferPage() {
  return (
    <main className="min-h-screen bg-canvas">
      <SiteHeader />
      <TitleTransferForm />
    </main>
  );
}
