import TitleLineageViewer from "@/components/legal/TitleLineageViewer";
import SiteHeader from "@/components/layout/SiteHeader";

export default function LineagePage() {
  return (
    <main className="min-h-screen bg-canvas">
      <SiteHeader />
      <TitleLineageViewer />
    </main>
  );
}
