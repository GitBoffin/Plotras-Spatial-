import AuthForm from "@/components/auth/AuthForm";

export default function LoginPage() {
  return (
    <main className="min-h-screen bg-canvas">
      <AuthForm mode="login" />
    </main>
  );
}
