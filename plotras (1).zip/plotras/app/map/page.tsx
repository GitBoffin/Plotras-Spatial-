// =====================================================================
// PLOTRAS — /map
// Full-bleed parcel viewer. Wrapped in its own page (rather than the
// dashboard shell) since the map wants the full viewport.
// =====================================================================

import ParcelMapViewer from "@/components/parcel-map/ParcelMapViewer";

export default function MapPage() {
  return (
    <main className="h-screen w-screen overflow-hidden bg-canvas">
      <ParcelMapViewer />
    </main>
  );
}
