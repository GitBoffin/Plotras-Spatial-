import Link from "next/link";
import SiteHeader from "@/components/layout/SiteHeader";

const SIGNALS = [
  {
    key: "GREEN",
    color: "#22C55E",
    label: "Clean Title",
    body: "Nobody else has bought it, no bank holds a loan on it, and the state does not own it.",
  },
  {
    key: "YELLOW",
    color: "#EAB308",
    label: "Active Bank Lien",
    body: "The land is real, but it already secures a loan. Don't pay until that's discharged.",
  },
  {
    key: "RED",
    color: "#EF4444",
    label: "High Risk Collision",
    body: "The coordinates overlap a registered plot or sit inside a government acquisition zone.",
  },
] as const;

export default function HomePage() {
  return (
    <main className="min-h-screen bg-canvas">
      <SiteHeader />

      <section className="mx-auto max-w-6xl px-6 py-20">
        <div className="max-w-2xl">
          <p className="mb-4 text-sm text-brass">Spatial Title Verification</p>
          <h1 className="font-serif text-4xl leading-tight text-foreground sm:text-5xl">
            Check the ground, not the paper.
          </h1>
          <p className="mt-5 text-base leading-relaxed text-foreground-muted">
            Instead of trusting a piece of paper, Plotras checks the exact coordinates a
            parcel sits on against the registry, active bank liens, and government
            acquisition zones — before any money changes hands.
          </p>
          <div className="mt-8 flex gap-3">
            <Link
              href="/map"
              className="rounded-card bg-brass px-5 py-2.5 text-sm font-medium text-canvas transition-opacity hover:opacity-90"
            >
              Open Parcel Map
            </Link>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-6 pb-20">
        <p className="mb-4 text-xs text-foreground-muted">How a check resolves</p>
        <div className="grid gap-4 sm:grid-cols-3">
          {SIGNALS.map((signal) => (
            <div
              key={signal.key}
              className="rounded-card border border-border bg-canvas-raised p-5"
            >
              <span
                className="mb-3 inline-block h-2.5 w-2.5 rounded-seal"
                style={{ backgroundColor: signal.color }}
              />
              <h2 className="font-serif text-lg text-foreground">{signal.label}</h2>
              <p className="mt-2 text-sm leading-relaxed text-foreground-muted">
                {signal.body}
              </p>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}
