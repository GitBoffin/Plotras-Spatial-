import AuthForm from "@/components/auth/AuthForm";

export default function SignupPage() {
  return (
    <main className="min-h-screen bg-canvas">
      <AuthForm mode="signup" />
    </main>
  );
}
