import DraftSurveyForm from "@/components/survey/DraftSurveyForm";
import SiteHeader from "@/components/layout/SiteHeader";

export default function SurveySubmitPage() {
  return (
    <main className="min-h-screen bg-canvas">
      <SiteHeader />
      <DraftSurveyForm />
    </main>
  );
}
