// =====================================================================
// PLOTRAS — /verify/[reportId]
// =====================================================================
// Public, unauthenticated on purpose — PRD FR-003/MVP gate: "QR
// verification resolves to the corresponding verification record."
// Anyone scanning a Plotras certificate's QR code (a buyer's lawyer, a
// bank, a government official) lands here and sees the authoritative
// record independent of whatever is printed on the PDF in their hand.
// =====================================================================

import { createClient } from "@supabase/supabase-js";

const SIGNAL_LABELS: Record<string, string> = {
  GREEN: "Clean Title",
  YELLOW: "Active Bank Lien",
  RED: "High Risk Collision",
};

const SIGNAL_COLORS: Record<string, string> = {
  GREEN: "#22C55E",
  YELLOW: "#EAB308",
  RED: "#EF4444",
};

async function getCertificate(reportId: string) {
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { persistSession: false } }
  );

  const { data } = await supabase
    .from("certificates")
    .select("report_id, spatial_id, status, signal, state_code, lga, sha256_hash, issued_at")
    .eq("report_id", reportId)
    .maybeSingle();

  return data;
}

export default async function VerifyReportPage({
  params,
}: {
  params: { reportId: string };
}) {
  const cert = await getCertificate(params.reportId);

  return (
    <main className="flex min-h-screen items-center justify-center bg-canvas px-6">
      <div className="w-full max-w-md rounded-card border border-border bg-canvas-raised p-8">
        <p className="mb-1 text-sm text-brass">Plotras</p>
        <h1 className="mb-6 font-serif text-2xl text-foreground">Certificate Verification</h1>

        {!cert ? (
          <div className="rounded-card border border-signal-red-border bg-signal-red-bg px-4 py-3 text-sm text-foreground">
            This is not a valid Plotras certificate. If you scanned a QR code from a
            printed document, the report ID does not match anything on file.
          </div>
        ) : (
          <>
            <div
              className="mb-5 flex items-center gap-2 rounded-card border border-signal-green-border bg-signal-green-bg px-4 py-3"
              style={{ borderColor: SIGNAL_COLORS[cert.signal] + "88" }}
            >
              <span
                className="h-2.5 w-2.5 shrink-0 rounded-seal"
                style={{ backgroundColor: SIGNAL_COLORS[cert.signal] }}
              />
              <p className="text-sm text-foreground">
                Verified — this certificate matches Plotras records on file.
              </p>
            </div>

            <dl className="space-y-3 text-sm">
              <Row label="Spatial ID" value={cert.spatial_id} />
              <Row label="Signal" value={SIGNAL_LABELS[cert.signal] ?? cert.signal} />
              <Row label="Parcel status" value={cert.status.replaceAll("_", " ")} />
              <Row label="Location" value={`${cert.lga}, ${cert.state_code}`} />
              <Row label="Issued" value={new Date(cert.issued_at).toUTCString()} />
            </dl>

            <p className="mt-6 break-all rounded-card border border-border bg-canvas px-3 py-2 font-mono text-xs text-foreground-faint">
              SHA-256: {cert.sha256_hash}
            </p>

            <p className="mt-4 text-xs leading-relaxed text-foreground-faint">
              This page confirms the certificate's contents match what Plotras issued.
              It is not itself a statutory declaration of ownership or legal title.
            </p>
          </>
        )}
      </div>
    </main>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between">
      <dt className="text-foreground-muted">{label}</dt>
      <dd className="text-foreground">{value}</dd>
    </div>
  );
}
