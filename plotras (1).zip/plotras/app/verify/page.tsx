import BeaconVerifyForm from "@/components/verify/BeaconVerifyForm";
import SiteHeader from "@/components/layout/SiteHeader";

export default function VerifyPage() {
  return (
    <main className="min-h-screen bg-canvas">
      <SiteHeader />
      <BeaconVerifyForm />
    </main>
  );
}
