"use client";

// =====================================================================
// PLOTRAS — Parcel Map Viewer
// =====================================================================
// Renders registered parcels from fn_parcels_geojson() (supabase/schema
// additions — see migration fn_parcels_geojson) as a Mapbox GL layer,
// colored by title signal (GREEN / YELLOW / RED per PRD Part I). Click
// a parcel to open a certificate-style status panel.
//
// Phase 3: "Satellite imagery overlays" — implemented via Mapbox's own
// satellite-streets tileset (a real, genuinely-buildable piece of this
// requirement, unlike government registry sync or unmapped-development
// detection, which need actual external data/ML this project doesn't
// have). Toggling calls map.setStyle(), which fully replaces the
// style's sources/layers — parcel data is re-attached on the
// resulting 'style.load' event rather than re-fetched from Supabase.
//
// Requires:
//   npm install mapbox-gl
//   npm install -D @types/mapbox-gl
//
// Env:
//   NEXT_PUBLIC_MAPBOX_TOKEN=<your Mapbox access token>
// =====================================================================

import { useEffect, useRef, useState } from "react";
import mapboxgl, { type MapMouseEvent } from "mapbox-gl";
import "mapbox-gl/dist/mapbox-gl.css";
import { supabaseBrowser } from "@/lib/supabase/client";

mapboxgl.accessToken = process.env.NEXT_PUBLIC_MAPBOX_TOKEN ?? "";

type Signal = "GREEN" | "YELLOW" | "RED";
type BaseStyle = "dark" | "satellite";

interface ParcelProperties {
  id: string;
  spatial_id: string;
  status: string;
  state_code: string;
  lga: string;
  title_type: string | null;
  signal: Signal;
}

// Mirrors tailwind.config.ts `signal` tokens — kept as literal hex here
// because Mapbox GL style expressions can't read CSS custom properties.
const SIGNAL_COLORS: Record<Signal, string> = {
  GREEN: "#22C55E",
  YELLOW: "#EAB308",
  RED: "#EF4444",
};

const SIGNAL_LABELS: Record<Signal, string> = {
  GREEN: "Clean Title",
  YELLOW: "Active Bank Lien",
  RED: "High Risk Collision",
};

const BRASS = "#F0C265";
const CANVAS_INSET = "#0F0F0F";

const STYLE_URLS: Record<BaseStyle, string> = {
  dark: "mapbox://styles/mapbox/dark-v11",
  satellite: "mapbox://styles/mapbox/satellite-streets-v12",
};

const DEFAULT_CENTER: [number, number] = [3.4219, 6.4531]; // PRD's Lagos worked example
const DEFAULT_ZOOM = 15;

function attachParcelLayers(map: mapboxgl.Map, data: GeoJSON.FeatureCollection) {
  if (map.getSource("parcels")) return; // already attached (e.g. duplicate style.load)

  map.addSource("parcels", { type: "geojson", data });

  map.addLayer({
    id: "parcels-fill",
    type: "fill",
    source: "parcels",
    paint: {
      "fill-color": [
        "match",
        ["get", "signal"],
        "GREEN",
        SIGNAL_COLORS.GREEN,
        "YELLOW",
        SIGNAL_COLORS.YELLOW,
        "RED",
        SIGNAL_COLORS.RED,
        /* fallback */ "#6B6B6B",
      ],
      "fill-opacity": 0.28,
    },
  });

  map.addLayer({
    id: "parcels-outline",
    type: "line",
    source: "parcels",
    paint: {
      "line-color": [
        "match",
        ["get", "signal"],
        "GREEN",
        SIGNAL_COLORS.GREEN,
        "YELLOW",
        SIGNAL_COLORS.YELLOW,
        "RED",
        SIGNAL_COLORS.RED,
        "#6B6B6B",
      ],
      "line-width": 1.5,
    },
  });

  // Brass selection outline — only visible on the clicked parcel.
  map.addLayer({
    id: "parcels-selected-outline",
    type: "line",
    source: "parcels",
    paint: { "line-color": BRASS, "line-width": 3 },
    filter: ["==", ["get", "spatial_id"], ""],
  });
}

export default function ParcelMapViewer() {
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<mapboxgl.Map | null>(null);
  const parcelDataRef = useRef<GeoJSON.FeatureCollection | null>(null);
  const baseStyleRef = useRef<BaseStyle>("dark");
  const [selected, setSelected] = useState<ParcelProperties | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [baseStyle, setBaseStyle] = useState<BaseStyle>("dark");

  useEffect(() => {
    if (!mapContainerRef.current || mapRef.current) return;

    const map = new mapboxgl.Map({
      container: mapContainerRef.current,
      style: STYLE_URLS.dark,
      center: DEFAULT_CENTER,
      zoom: DEFAULT_ZOOM,
      pitch: 0,
      attributionControl: true,
    });
    mapRef.current = map;

    map.addControl(new mapboxgl.NavigationControl({ visualizePitch: false }), "top-right");

    // Click/hover handlers bound by layer id survive setStyle() calls —
    // Mapbox resolves them against whatever layer currently has that id
    // in the active style, not a fixed reference — so these only need
    // to be attached once, here, not re-attached after every style swap.
    map.on("click", "parcels-fill", (e: MapMouseEvent) => {
      const feature = e.features?.[0];
      if (!feature) return;
      const props = feature.properties as ParcelProperties;
      setSelected(props);
      map.setFilter("parcels-selected-outline", ["==", ["get", "spatial_id"], props.spatial_id]);
    });
    map.on("mouseenter", "parcels-fill", () => { map.getCanvas().style.cursor = "pointer"; });
    map.on("mouseleave", "parcels-fill", () => { map.getCanvas().style.cursor = ""; });

    map.on("style.load", () => {
      // Recolor only the dark style toward the institutional charcoal
      // canvas — leave satellite imagery untouched.
      if (baseStyleRef.current === "dark") {
        try {
          map.setPaintProperty("background", "background-color", CANVAS_INSET);
          map.setPaintProperty("water", "fill-color", "#101820");
        } catch {
          // Layer ids can vary by style version — non-fatal if unset.
        }
      }
      if (parcelDataRef.current) attachParcelLayers(map, parcelDataRef.current);
    });

    map.on("load", async () => {
      const { data, error } = await supabaseBrowser.rpc("fn_parcels_geojson");

      if (error) {
        setLoadError(error.message);
        setLoading(false);
        return;
      }

      parcelDataRef.current = data as GeoJSON.FeatureCollection;
      attachParcelLayers(map, parcelDataRef.current);
      setLoading(false);
    });

    return () => {
      map.remove();
      mapRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function switchStyle(style: BaseStyle) {
    if (style === baseStyle || !mapRef.current) return;
    setBaseStyle(style);
    baseStyleRef.current = style;
    setSelected(null);
    mapRef.current.setStyle(STYLE_URLS[style]);
    // attachParcelLayers runs again via the 'style.load' listener above.
  }

  return (
    <div className="relative h-full w-full bg-canvas font-sans">
      {/* Subtle GIS-terminal grid overlay — dark style only; would look
          wrong layered over real satellite imagery. */}
      {baseStyle === "dark" && (
        <div
          className="pointer-events-none absolute inset-0 z-10 bg-grid-overlay bg-grid opacity-40"
          aria-hidden="true"
        />
      )}

      <div ref={mapContainerRef} className="h-full w-full" />

      {loading && (
        <div className="absolute inset-0 z-20 flex items-center justify-center bg-canvas/80">
          <p className="font-serif text-lg text-foreground-muted">
            Loading registered parcels…
          </p>
        </div>
      )}

      {loadError && (
        <div className="absolute left-1/2 top-4 z-30 -translate-x-1/2 rounded-card border border-signal-red-border bg-signal-red-bg px-4 py-2 text-sm text-foreground">
          Could not load parcel data: {loadError}
        </div>
      )}

      <StyleToggle current={baseStyle} onChange={switchStyle} />
      <SignalLegend />

      {selected && (
        <ParcelStatusPanel
          parcel={selected}
          onClose={() => {
            setSelected(null);
            mapRef.current?.setFilter("parcels-selected-outline", ["==", ["get", "spatial_id"], ""]);
          }}
        />
      )}
    </div>
  );
}

// ---------------------------------------------------------------------
// Base style toggle
// ---------------------------------------------------------------------

function StyleToggle({ current, onChange }: { current: BaseStyle; onChange: (s: BaseStyle) => void }) {
  return (
    <div className="absolute left-6 top-6 z-20 flex overflow-hidden rounded-card border border-border bg-canvas-raised/95 text-xs shadow-panel backdrop-blur-sm">
      {(["dark", "satellite"] as BaseStyle[]).map((s) => (
        <button
          key={s}
          onClick={() => onChange(s)}
          className="px-3 py-2 capitalize transition-colors"
          style={{
            color: current === s ? "#141414" : "#A3A3A3",
            backgroundColor: current === s ? BRASS : "transparent",
          }}
        >
          {s}
        </button>
      ))}
    </div>
  );
}

// ---------------------------------------------------------------------
// Legend
// ---------------------------------------------------------------------

function SignalLegend() {
  return (
    <div className="absolute bottom-6 left-6 z-20 rounded-card border border-border bg-canvas-raised/95 px-4 py-3 shadow-panel backdrop-blur-sm">
      <p className="mb-2 text-xs font-medium tracking-normal text-foreground-muted">
        Title Signal
      </p>
      <ul className="flex flex-col gap-1.5">
        {(Object.keys(SIGNAL_COLORS) as Signal[]).map((signal) => (
          <li key={signal} className="flex items-center gap-2 text-sm text-foreground">
            <span
              className="h-2.5 w-2.5 rounded-seal"
              style={{ backgroundColor: SIGNAL_COLORS[signal] }}
            />
            {SIGNAL_LABELS[signal]}
          </li>
        ))}
      </ul>
    </div>
  );
}

// ---------------------------------------------------------------------
// Status panel — the "official certificate" moment for a clicked parcel
// ---------------------------------------------------------------------

function ParcelStatusPanel({
  parcel,
  onClose,
}: {
  parcel: ParcelProperties;
  onClose: () => void;
}) {
  const isClean = parcel.signal === "GREEN";

  return (
    <div className="absolute right-6 top-6 z-20 w-80 overflow-hidden rounded-card border border-border bg-canvas-raised shadow-panel">
      <div
        className="flex items-center justify-between border-b border-border px-5 py-4"
        style={{
          backgroundColor:
            parcel.signal === "GREEN"
              ? "#152A1E"
              : parcel.signal === "YELLOW"
              ? "#2A2412"
              : "#2A1414",
        }}
      >
        <div>
          <p className="font-serif text-lg text-foreground">{parcel.spatial_id}</p>
          <p className="text-xs text-foreground-muted">
            {parcel.lga}, {parcel.state_code}
          </p>
        </div>
        {isClean && (
          <div
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-seal border"
            style={{ borderColor: BRASS, boxShadow: "0 0 0 1px rgba(240,194,101,0.35)" }}
            title="Plotras Verified"
          >
            <span className="text-xs font-semibold" style={{ color: BRASS }}>
              ✓
            </span>
          </div>
        )}
      </div>

      <div className="space-y-3 px-5 py-4">
        <StatusRow label="Signal" value={SIGNAL_LABELS[parcel.signal]} signal={parcel.signal} />
        <StatusRow label="Parcel status" value={parcel.status.replaceAll("_", " ")} />
        <StatusRow label="Title type" value={parcel.title_type ?? "Not yet on file"} />
      </div>

      <button
        onClick={onClose}
        className="w-full border-t border-border px-5 py-3 text-left text-sm text-foreground-muted transition-colors hover:bg-canvas hover:text-foreground"
      >
        Close report
      </button>
    </div>
  );
}

function StatusRow({
  label,
  value,
  signal,
}: {
  label: string;
  value: string;
  signal?: Signal;
}) {
  return (
    <div className="flex items-center justify-between text-sm">
      <span className="text-foreground-muted">{label}</span>
      <span className="flex items-center gap-1.5 text-foreground">
        {signal && (
          <span
            className="h-1.5 w-1.5 rounded-seal"
            style={{ backgroundColor: SIGNAL_COLORS[signal] }}
          />
        )}
        {value}
      </span>
    </div>
  );
}
