"use client";

import { useEffect, useState } from "react";
import { supabaseBrowser } from "@/lib/supabase/client";

interface Beacon {
  beacon_no: string;
  lat: string;
  lng: string;
}

function emptyBeacon(): Beacon {
  return { beacon_no: "", lat: "", lng: "" };
}

export default function DraftSurveyForm() {
  const [role, setRole] = useState<string | null | "loading">("loading");
  const [beacons, setBeacons] = useState<Beacon[]>([emptyBeacon(), emptyBeacon(), emptyBeacon(), emptyBeacon()]);
  const [stateCode, setStateCode] = useState("");
  const [lga, setLga] = useState("");
  const [titleType, setTitleType] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState<{ spatial_id: string; parcel_status: string; validation_passed: boolean; validation_note: string } | null>(null);
  const [error, setError] = useState<{ code: string; message: string } | null>(null);

  useEffect(() => {
    supabaseBrowser.auth.getSession().then(async ({ data: { session } }) => {
      if (!session) return setRole(null);
      const { data } = await supabaseBrowser.from("users").select("role").eq("id", session.user.id).single();
      setRole(data?.role ?? null);
    });
  }, []);

  function updateBeacon(i: number, field: keyof Beacon, value: string) {
    setBeacons((prev) => prev.map((b, idx) => (idx === i ? { ...b, [field]: value } : b)));
  }
  function addBeacon() {
    setBeacons((prev) => [...prev, emptyBeacon()]);
  }
  function removeBeacon(i: number) {
    setBeacons((prev) => (prev.length <= 4 ? prev : prev.filter((_, idx) => idx !== i)));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setResult(null);
    setSubmitting(true);

    const {
      data: { session },
    } = await supabaseBrowser.auth.getSession();
    if (!session) {
      setError({ code: "ERR_UNAUTHENTICATED", message: "Sign in as a surveyor first." });
      setSubmitting(false);
      return;
    }

    const parsedBeacons = beacons.map((b) => ({
      beacon_no: b.beacon_no.trim(),
      lat: parseFloat(b.lat),
      lng: parseFloat(b.lng),
    }));

    const res = await fetch("/api/v1/survey/submit", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${session.access_token}` },
      body: JSON.stringify({ beacons: parsedBeacons, state_code: stateCode.trim(), lga: lga.trim(), title_type: titleType || undefined }),
    });
    const body = await res.json();

    if (!res.ok) {
      setError(body.error);
    } else {
      setResult(body);
      setBeacons([emptyBeacon(), emptyBeacon(), emptyBeacon(), emptyBeacon()]);
      setStateCode("");
      setLga("");
      setTitleType("");
    }
    setSubmitting(false);
  }

  if (role === "loading") return <p className="px-6 py-16 text-sm text-foreground-muted">Loading…</p>;

  if (role !== "SURVEYOR" && role !== "GOVT_ADMIN") {
    return (
      <div className="mx-auto max-w-lg px-6 py-16">
        <p className="rounded-card border border-signal-yellow-border bg-signal-yellow-bg px-4 py-3 text-sm text-foreground">
          Submitting a draft survey is only available to SURVEYOR or GOVT_ADMIN accounts.
        </p>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-2xl px-6 py-16">
      <p className="mb-2 text-sm text-brass">Field Survey</p>
      <h1 className="mb-3 font-serif text-3xl text-foreground">Submit Draft Survey</h1>
      <p className="mb-8 text-sm leading-relaxed text-foreground-muted">
        Registers a new parcel from field beacon coordinates. Automated spatial
        validation checks for overlaps with existing parcels and government
        restricted zones — a clean survey advances straight to PENDING_CHARTING;
        a conflicted one holds at DRAFT_SURVEY for manual review.
      </p>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-3 gap-3">
          <input value={stateCode} onChange={(e) => setStateCode(e.target.value)} placeholder="State code (e.g. LAG)" required
            className="rounded-card border border-border bg-canvas-raised px-3 py-2 text-sm text-foreground placeholder:text-foreground-faint focus:border-brass-muted focus:outline-none" />
          <input value={lga} onChange={(e) => setLga(e.target.value)} placeholder="LGA" required
            className="rounded-card border border-border bg-canvas-raised px-3 py-2 text-sm text-foreground placeholder:text-foreground-faint focus:border-brass-muted focus:outline-none" />
          <input value={titleType} onChange={(e) => setTitleType(e.target.value)} placeholder="Title type (optional)"
            className="rounded-card border border-border bg-canvas-raised px-3 py-2 text-sm text-foreground placeholder:text-foreground-faint focus:border-brass-muted focus:outline-none" />
        </div>

        <div className="space-y-3">
          {beacons.map((beacon, i) => (
            <div key={i} className="grid grid-cols-[1fr_1fr_1fr_auto] items-center gap-3 rounded-card border border-border bg-canvas-raised p-3">
              <input placeholder={`Beacon no.`} value={beacon.beacon_no} onChange={(e) => updateBeacon(i, "beacon_no", e.target.value)}
                className="rounded-card border border-border bg-canvas px-3 py-2 text-sm text-foreground placeholder:text-foreground-faint focus:border-brass-muted focus:outline-none" />
              <input placeholder="Latitude" inputMode="decimal" value={beacon.lat} onChange={(e) => updateBeacon(i, "lat", e.target.value)}
                className="rounded-card border border-border bg-canvas px-3 py-2 text-sm text-foreground placeholder:text-foreground-faint focus:border-brass-muted focus:outline-none" />
              <input placeholder="Longitude" inputMode="decimal" value={beacon.lng} onChange={(e) => updateBeacon(i, "lng", e.target.value)}
                className="rounded-card border border-border bg-canvas px-3 py-2 text-sm text-foreground placeholder:text-foreground-faint focus:border-brass-muted focus:outline-none" />
              <button type="button" onClick={() => removeBeacon(i)} disabled={beacons.length <= 4}
                className="px-2 text-sm text-foreground-faint hover:text-signal-red disabled:cursor-not-allowed disabled:opacity-30">
                ✕
              </button>
            </div>
          ))}
        </div>

        <button type="button" onClick={addBeacon} className="text-sm text-brass-muted hover:text-brass">
          + Add beacon
        </button>

        {error && (
          <div className="rounded-card border border-signal-red-border bg-signal-red-bg px-4 py-3">
            <p className="font-mono text-xs text-foreground-muted">{error.code}</p>
            <p className="mt-1 text-sm text-foreground">{error.message}</p>
          </div>
        )}

        <button type="submit" disabled={submitting}
          className="w-full rounded-card bg-brass px-5 py-3 text-sm font-medium text-canvas transition-opacity hover:opacity-90 disabled:opacity-50">
          {submitting ? "Submitting…" : "Submit Draft Survey"}
        </button>
      </form>

      {result && (
        <div
          className="mt-8 rounded-card border px-5 py-4"
          style={{
            borderColor: result.validation_passed ? "#1F6B3B" : "#8A6D14",
            backgroundColor: result.validation_passed ? "#152A1E" : "#2A2412",
          }}
        >
          <p className="font-serif text-lg text-foreground">{result.spatial_id}</p>
          <p className="mt-1 text-sm text-foreground-muted">Status: {result.parcel_status}</p>
          <p className="mt-2 text-xs text-foreground-muted">{result.validation_note}</p>
        </div>
      )}
    </div>
  );
}
