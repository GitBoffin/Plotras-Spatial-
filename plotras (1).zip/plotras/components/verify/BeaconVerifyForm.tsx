"use client";

// =====================================================================
// PLOTRAS — Beacon Verification Form
// =====================================================================
// Client-side counterpart to app/api/v1/spatial/verify/route.ts.
// Collects >= 4 beacon coordinates (PRD 4.A: search_mode "BEACONS"),
// submits them, and renders the resulting GREEN/YELLOW/RED report in
// the same certificate visual language as ParcelStatusPanel.
// =====================================================================

import { useState } from "react";
import Script from "next/script";
import { supabaseBrowser } from "@/lib/supabase/client";

declare global {
  interface Window {
    PaystackPop?: {
      setup: (config: Record<string, unknown>) => { openIframe: () => void };
    };
  }
}

type Signal = "GREEN" | "YELLOW" | "RED";

interface Beacon {
  beacon_no: string;
  lat: string;
  lng: string;
}

interface VerifySuccess {
  status: "success";
  data: {
    spatial_id: string;
    signal: Signal;
    overlap_percentage: number;
    encumbrances_found: boolean;
    govt_acquisition: string | null;
    unlock_fee_naira: number;
    report_access_token: string;
  };
}

interface VerifyError {
  error: {
    code: string;
    message: string;
    details?: unknown[];
    timestamp: string;
  };
}

const SIGNAL_COLORS: Record<Signal, string> = {
  GREEN: "#22C55E",
  YELLOW: "#EAB308",
  RED: "#EF4444",
};

const SIGNAL_HEADLINES: Record<Signal, string> = {
  GREEN: "Clean Title. Zero coordinate collisions. No bank liens registered.",
  YELLOW: "This land is real, but a lien is registered against it.",
  RED: "High Risk Alert. This geometry collides with an existing record.",
};

function emptyBeacon(): Beacon {
  return { beacon_no: "", lat: "", lng: "" };
}

export default function BeaconVerifyForm() {
  const [beacons, setBeacons] = useState<Beacon[]>([
    emptyBeacon(),
    emptyBeacon(),
    emptyBeacon(),
    emptyBeacon(),
  ]);
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState<VerifySuccess["data"] | null>(null);
  const [apiError, setApiError] = useState<VerifyError["error"] | null>(null);
  const [formError, setFormError] = useState<string | null>(null);

  function updateBeacon(index: number, field: keyof Beacon, value: string) {
    setBeacons((prev) =>
      prev.map((b, i) => (i === index ? { ...b, [field]: value } : b))
    );
  }

  function addBeacon() {
    setBeacons((prev) => [...prev, emptyBeacon()]);
  }

  function removeBeacon(index: number) {
    setBeacons((prev) => (prev.length <= 4 ? prev : prev.filter((_, i) => i !== index)));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setFormError(null);
    setApiError(null);
    setResult(null);

    // Client-side mirror of ERR_INVALID_GEOMETRY_MIN_BEACONS — the API
    // enforces this too, but catching it here saves a round trip.
    if (beacons.length < 4) {
      setFormError("At least 4 beacon coordinates are required.");
      return;
    }

    const parsedBeacons = [];
    for (const b of beacons) {
      const lat = parseFloat(b.lat);
      const lng = parseFloat(b.lng);
      if (!b.beacon_no.trim() || Number.isNaN(lat) || Number.isNaN(lng)) {
        setFormError("Every beacon needs a number, latitude, and longitude.");
        return;
      }
      parsedBeacons.push({ beacon_no: b.beacon_no.trim(), lat, lng });
    }

    setSubmitting(true);
    try {
      const {
        data: { session },
      } = await supabaseBrowser.auth.getSession();

      if (!session) {
        setFormError("Sign in required — please log in before running a spatial check.");
        setSubmitting(false);
        return;
      }

      const res = await fetch("/api/v1/spatial/verify", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({ search_mode: "BEACONS", beacons: parsedBeacons }),
      });

      const body = await res.json();

      if (!res.ok) {
        setApiError((body as VerifyError).error);
      } else {
        setResult((body as VerifySuccess).data);
      }
    } catch {
      setFormError("Could not reach the verification service. Try again.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="mx-auto max-w-2xl px-6 py-16">
      <Script src="https://js.paystack.co/v1/inline.js" strategy="lazyOnload" />
      <p className="mb-2 text-sm text-brass">Title Verification</p>
      <h1 className="mb-3 font-serif text-3xl text-foreground">Verify Coordinates</h1>
      <p className="mb-10 text-sm leading-relaxed text-foreground-muted">
        Enter the 4+ beacon numbers directly from the survey plan. Plotras runs a
        PostGIS spatial collision check against registered parcels, active bank
        liens, and government acquisition zones.
      </p>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="space-y-3">
          {beacons.map((beacon, i) => (
            <div
              key={i}
              className="grid grid-cols-[1fr_1fr_1fr_auto] items-center gap-3 rounded-card border border-border bg-canvas-raised p-3"
            >
              <input
                placeholder={`Beacon no. (e.g. N123${i + 4})`}
                value={beacon.beacon_no}
                onChange={(e) => updateBeacon(i, "beacon_no", e.target.value)}
                className="rounded-card border border-border bg-canvas px-3 py-2 text-sm text-foreground placeholder:text-foreground-faint focus:border-brass-muted focus:outline-none"
              />
              <input
                placeholder="Latitude"
                inputMode="decimal"
                value={beacon.lat}
                onChange={(e) => updateBeacon(i, "lat", e.target.value)}
                className="rounded-card border border-border bg-canvas px-3 py-2 text-sm text-foreground placeholder:text-foreground-faint focus:border-brass-muted focus:outline-none"
              />
              <input
                placeholder="Longitude"
                inputMode="decimal"
                value={beacon.lng}
                onChange={(e) => updateBeacon(i, "lng", e.target.value)}
                className="rounded-card border border-border bg-canvas px-3 py-2 text-sm text-foreground placeholder:text-foreground-faint focus:border-brass-muted focus:outline-none"
              />
              <button
                type="button"
                onClick={() => removeBeacon(i)}
                disabled={beacons.length <= 4}
                className="px-2 text-sm text-foreground-faint transition-colors hover:text-signal-red disabled:cursor-not-allowed disabled:opacity-30"
                aria-label="Remove beacon"
              >
                ✕
              </button>
            </div>
          ))}
        </div>

        <button
          type="button"
          onClick={addBeacon}
          className="text-sm text-brass-muted transition-colors hover:text-brass"
        >
          + Add beacon
        </button>

        {formError && <p className="text-sm text-signal-red">{formError}</p>}

        <button
          type="submit"
          disabled={submitting}
          className="w-full rounded-card bg-brass px-5 py-3 text-sm font-medium text-canvas transition-opacity hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-50"
        >
          {submitting ? "Running spatial check…" : "Run Spatial Check"}
        </button>
      </form>

      {apiError && (
        <div className="mt-8 rounded-card border border-signal-red-border bg-signal-red-bg p-5">
          <p className="font-mono text-xs text-foreground-muted">{apiError.code}</p>
          <p className="mt-1 text-sm text-foreground">{apiError.message}</p>
        </div>
      )}

      {result && <VerifyResultCard data={result} />}
    </div>
  );
}

function VerifyResultCard({ data }: { data: VerifySuccess["data"] }) {
  const bg =
    data.signal === "GREEN" ? "#152A1E" : data.signal === "YELLOW" ? "#2A2412" : "#2A1414";
  const border =
    data.signal === "GREEN" ? "#1F6B3B" : data.signal === "YELLOW" ? "#8A6D14" : "#8A2222";

  const [unlockState, setUnlockState] = useState<
    "idle" | "starting" | "awaiting_payment" | "polling" | "unlocked" | "error"
  >("idle");
  const [unlockError, setUnlockError] = useState<string | null>(null);

  async function pollUntilUnlocked(token: string, attemptsLeft = 20) {
    if (attemptsLeft <= 0) {
      setUnlockState("error");
      setUnlockError("Payment confirmation is taking longer than expected. Refresh in a minute.");
      return;
    }
    const res = await fetch(`/api/v1/reports/status?token=${token}`);
    const body = await res.json();
    if (body.unlocked) {
      setUnlockState("unlocked");
      return;
    }
    setTimeout(() => pollUntilUnlocked(token, attemptsLeft - 1), 3000);
  }

  async function handleUnlock() {
    setUnlockState("starting");
    setUnlockError(null);

    const {
      data: { session },
    } = await supabaseBrowser.auth.getSession();

    if (!session) {
      setUnlockState("error");
      setUnlockError("Sign in required to unlock a report.");
      return;
    }

    try {
      const res = await fetch("/api/v1/reports/unlock-intent", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({
          spatial_id: data.spatial_id,
          report_access_token: data.report_access_token,
        }),
      });

      const intent = await res.json();

      if (!res.ok || !intent.public_key) {
        setUnlockState("error");
        setUnlockError(
          intent.error?.message ??
            "Payment isn't configured yet — NEXT_PUBLIC_PAYSTACK_PUBLIC_KEY is missing."
        );
        return;
      }

      if (!window.PaystackPop) {
        setUnlockState("error");
        setUnlockError("Payment script hasn't finished loading — try again in a moment.");
        return;
      }

      setUnlockState("awaiting_payment");

      const handler = window.PaystackPop.setup({
        key: intent.public_key,
        email: intent.email,
        amount: intent.amount_kobo,
        ref: intent.reference,
        currency: "NGN",
        callback: () => {
          // Paystack's own callback fires on popup success, but the
          // report only actually unlocks once our webhook confirms the
          // charge server-side — poll rather than trust this alone.
          setUnlockState("polling");
          pollUntilUnlocked(data.report_access_token);
        },
        onClose: () => {
          setUnlockState((s) => (s === "awaiting_payment" ? "idle" : s));
        },
      });

      handler.openIframe();
    } catch {
      setUnlockState("error");
      setUnlockError("Could not start the payment. Try again.");
    }
  }

  return (
    <div
      className="mt-8 overflow-hidden rounded-card border"
      style={{ borderColor: border }}
    >
      <div className="px-6 py-6" style={{ backgroundColor: bg }}>
        <div className="mb-3 flex items-center gap-2">
          <span
            className="h-3 w-3 rounded-seal"
            style={{ backgroundColor: SIGNAL_COLORS[data.signal] }}
          />
          <span className="text-xs uppercase tracking-normal text-foreground-muted">
            {data.signal} light
          </span>
        </div>
        <p className="font-serif text-lg leading-snug text-foreground">
          {SIGNAL_HEADLINES[data.signal]}
        </p>
      </div>

      <div className="space-y-3 bg-canvas-raised px-6 py-5">
        <Row label="Spatial ID" value={data.spatial_id} />
        <Row label="Overlap" value={`${data.overlap_percentage.toFixed(2)}%`} />
        <Row label="Active liens" value={data.encumbrances_found ? "Yes" : "None"} />
        <Row label="Govt. acquisition zone" value={data.govt_acquisition ?? "None"} />
        <Row label="Unlock fee" value={`₦${data.unlock_fee_naira.toLocaleString()}`} />
      </div>

      {unlockState === "unlocked" ? (
        <div className="border-t border-border px-6 py-4">
          <p className="text-sm text-signal-green">
            ✓ Report unlocked. Full title history and beacon coordinates are now available.
          </p>
          <button
            onClick={async () => {
              const {
                data: { session },
              } = await supabaseBrowser.auth.getSession();
              if (!session) return;
              const res = await fetch(
                `/api/v1/reports/certificate?token=${data.report_access_token}`,
                { headers: { Authorization: `Bearer ${session.access_token}` } }
              );
              if (!res.ok) return;
              const blob = await res.blob();
              const url = URL.createObjectURL(blob);
              const a = document.createElement("a");
              a.href = url;
              a.download = `plotras-${data.spatial_id}.pdf`;
              a.click();
              URL.revokeObjectURL(url);
            }}
            className="mt-3 rounded-card bg-brass px-4 py-2 text-xs font-medium text-canvas transition-opacity hover:opacity-90"
          >
            Download Certificate (PDF)
          </button>
        </div>
      ) : (
        <button
          onClick={handleUnlock}
          disabled={unlockState === "starting" || unlockState === "awaiting_payment" || unlockState === "polling"}
          className="w-full border-t border-border px-6 py-3 text-left text-sm text-brass transition-colors hover:bg-canvas disabled:cursor-not-allowed disabled:text-foreground-faint"
        >
          {unlockState === "starting" && "Starting payment…"}
          {unlockState === "awaiting_payment" && "Waiting on Paystack checkout…"}
          {unlockState === "polling" && "Confirming payment…"}
          {(unlockState === "idle" || unlockState === "error") &&
            `Unlock Full Report — ₦${data.unlock_fee_naira.toLocaleString()}`}
        </button>
      )}

      {unlockState === "error" && unlockError && (
        <p className="border-t border-border px-6 py-3 text-xs text-signal-red">{unlockError}</p>
      )}
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between text-sm">
      <span className="text-foreground-muted">{label}</span>
      <span className="text-foreground">{value}</span>
    </div>
  );
}
